// Passe de ray tracing (optionnelle) : pour chaque pixel du tampon RT,
// reconstruit la position monde depuis la profondeur, calcule la normale
// par différences de profondeur, puis lance des rayons contre les AABB
// de la scène :
//   - ombre douces des néons (rayon d'ombre par lumière proche, jitter stable)
//   - ombre de la lampe torche (rayon déterministe)
//   - occlusion ambiante (1 rayon en Qualité, 3 en Ultra) avec plancher de
//     lisibilité : plus de scènes écrasées au noir quand il n'y a pas de lumière
//   - un rebond de lumière approximatif depuis le point touché (Qualité+)
//   - RÉFLEXIONS PLEINE SCÈNE : le rayon miroir trace toute la scène (murs,
//     portes, baies) et se reflète dans le lino ciré ; la lumière dominante
//     ET la torche sont ré-éclairées au point réfléchi ; les néons ajoutent
//     leur halo spéculaire (cône gloss) — c'est le « wow » du ray tracing
// Sortie MRT : out0 = (ao, ombre_statique, ombre_torche, 1)
//              out1 = (gi.rgb + réflexions néon, 1)
// Résolution indépendante (0.4x / 0.5x du tampon monde) — pensé RTX 2060.

struct WorldU {
    view_proj: mat4x4<f32>,
    cam_pos: vec4<f32>,
    light_pos: array<vec4<f32>, 24>,
    light_col: array<vec4<f32>, 24>,
    flash_pos: vec4<f32>,
    flash_dir: vec4<f32>,
    misc: vec4<f32>,
    flash_col: vec4<f32>,
};

struct RtParams {
    inv_vp: mat4x4<f32>,
    cam_pos: vec4<f32>,
    dims: vec4<f32>,   // x,y : taille tampon RT · z,w : taille texture profondeur
    counts: vec4<f32>, // x : boîtes statiques · y : dynamiques · z : lumières · w : rayon AO
    misc: vec4<f32>,   // x : force GI · y : réserve · z : échantillons AO (1 ou 3) · w : réserve
};

struct GpuAabb {
    lo: vec4<f32>,
    hi: vec4<f32>,
};

@group(0) @binding(0) var<uniform> rp: RtParams;
@group(0) @binding(1) var<uniform> u: WorldU;
@group(0) @binding(2) var<storage, read> boxes_static: array<GpuAabb>;
@group(0) @binding(3) var<storage, read> boxes_dyn: array<GpuAabb>;
@group(0) @binding(4) var depth_tex: texture_depth_2d;

struct VSOut {
    @builtin(position) pos: vec4<f32>,
    @location(0) uv: vec2<f32>,
};

@vertex
fn vs(@builtin(vertex_index) vi: u32) -> VSOut {
    var pos = array<vec2<f32>, 3>(
        vec2<f32>(-1.0, -1.0),
        vec2<f32>(3.0, -1.0),
        vec2<f32>(-1.0, 3.0),
    );
    var out: VSOut;
    out.pos = vec4<f32>(pos[vi], 0.0, 1.0);
    out.uv = vec2<f32>((pos[vi].x + 1.0) * 0.5, 1.0 - (pos[vi].y + 1.0) * 0.5);
    return out;
}

// ---------- utilitaires ----------

fn hash3(p: vec3<f32>) -> vec3<f32> {
    let q = vec3<f32>(
        dot(p, vec3<f32>(127.1, 311.7, 74.7)),
        dot(p, vec3<f32>(269.5, 183.3, 246.1)),
        dot(p, vec3<f32>(113.5, 271.9, 124.6)),
    );
    return fract(sin(q) * vec3<f32>(43758.5453, 22578.145, 19642.349));
}

fn hash1(p: vec3<f32>) -> f32 {
    return fract(sin(dot(p, vec3<f32>(12.9898, 78.233, 45.164))) * 43758.5453);
}

/// Évite les divisions par zéro dans le slab test.
fn safe_dir(d: vec3<f32>) -> vec3<f32> {
    return select(d, vec3<f32>(1e-6), abs(d) < vec3<f32>(1e-8));
}

/// Slab test : t d'entrée (> 0) si la boîte est touchée avant tmax, sinon -1.
fn ray_aabb(ro: vec3<f32>, rd: vec3<f32>, b: GpuAabb, tmax: f32) -> f32 {
    if (b.hi.x <= b.lo.x || b.hi.y <= b.lo.y || b.hi.z <= b.lo.z) {
        return -1.0; // boîte dégénérée (padding) -> jamais touchée
    }
    let inv = vec3<f32>(1.0) / rd;
    let t0 = (b.lo.xyz - ro) * inv;
    let t1 = (b.hi.xyz - ro) * inv;
    let tmin3 = min(t0, t1);
    let tmax3 = max(t0, t1);
    let tmin = max(max(tmin3.x, tmin3.y), max(tmin3.z, 0.0));
    let tm = min(min(tmax3.x, tmax3.y), tmax3.z);
    if (tm < tmin || tmin > tmax) {
        return -1.0;
    }
    return tmin;
}

/// Rayon d'ombre : 0 si un obstacle est rencontré, 1 sinon (sortie anticipée).
fn shadow_ray(ro: vec3<f32>, rd_in: vec3<f32>, dist: f32) -> f32 {
    if (dist <= 0.03) {
        return 1.0;
    }
    let rd = safe_dir(rd_in);
    let sn = u32(rp.counts.x);
    for (var i = 0u; i < sn; i = i + 1u) {
        let t = ray_aabb(ro, rd, boxes_static[i], dist);
        if (t >= 0.0) {
            return 0.0;
        }
    }
    let dn = u32(rp.counts.y);
    for (var i = 0u; i < dn; i = i + 1u) {
        let t = ray_aabb(ro, rd, boxes_dyn[i], dist);
        if (t >= 0.0) {
            return 0.0;
        }
    }
    return 1.0;
}

/// La boîte contient-elle le point (avec marge) ?
fn box_contains(b: GpuAabb, pt: vec3<f32>, m: f32) -> bool {
    return pt.x >= b.lo.x - m && pt.x <= b.hi.x + m && pt.y >= b.lo.y - m && pt.y <= b.hi.y + m && pt.z >= b.lo.z - m && pt.z <= b.hi.z + m;
}

/// Rayon d'ombre vers un NÉON : ignore les boîtes qui contiennent le point
/// lumière (support du luminaire, dalle du plafond). Sans ça, le néon
/// s'auto-ombre : tous les halos disparaissent en RT (« tout est noir »).
fn shadow_ray_light(ro: vec3<f32>, rd_in: vec3<f32>, dist: f32, lt: vec3<f32>) -> f32 {
    if (dist <= 0.03) {
        return 1.0;
    }
    let rd = safe_dir(rd_in);
    let sn = u32(rp.counts.x);
    for (var i = 0u; i < sn; i = i + 1u) {
        if (box_contains(boxes_static[i], lt, 0.06)) {
            continue;
        }
        let t = ray_aabb(ro, rd, boxes_static[i], dist);
        if (t >= 0.0) {
            return 0.0;
        }
    }
    let dn = u32(rp.counts.y);
    for (var i = 0u; i < dn; i = i + 1u) {
        if (box_contains(boxes_dyn[i], lt, 0.06)) {
            continue;
        }
        let t = ray_aabb(ro, rd, boxes_dyn[i], dist);
        if (t >= 0.0) {
            return 0.0;
        }
    }
    return 1.0;
}

/// Trace un rayon contre toute la scène, renvoie le t du point le plus proche
/// (-1 si rien) et optionnellement la normale de la face touchée.
fn trace(ro: vec3<f32>, rd_in: vec3<f32>, tmax: f32, nrm: ptr<function, vec3<f32>>) -> f32 {
    let rd = safe_dir(rd_in);
    var best = tmax;
    var hit = false;
    let sn = u32(rp.counts.x);
    for (var i = 0u; i < sn; i = i + 1u) {
        let t = ray_aabb(ro, rd, boxes_static[i], best);
        if (t >= 0.0 && t < best) {
            best = t;
            hit = true;
            *nrm = aabb_normal(boxes_static[i], ro + rd * t);
        }
    }
    let dn = u32(rp.counts.y);
    for (var i = 0u; i < dn; i = i + 1u) {
        let t = ray_aabb(ro, rd, boxes_dyn[i], best);
        if (t >= 0.0 && t < best) {
            best = t;
            hit = true;
            *nrm = aabb_normal(boxes_dyn[i], ro + rd * t);
        }
    }
    return select(-1.0, best, hit);
}

/// Normale de la face d'AABB la plus proche d'un point de la surface.
fn aabb_normal(b: GpuAabb, p: vec3<f32>) -> vec3<f32> {
    var n = vec3<f32>(0.0, 1.0, 0.0);
    var best = abs(p.y - b.lo.y);
    var d = abs(p.y - b.hi.y);
    if (d < best) { best = d; n = vec3<f32>(0.0, -1.0, 0.0); }
    d = abs(p.x - b.lo.x);
    if (d < best) { best = d; n = vec3<f32>(-1.0, 0.0, 0.0); }
    d = abs(p.x - b.hi.x);
    if (d < best) { best = d; n = vec3<f32>(1.0, 0.0, 0.0); }
    d = abs(p.z - b.lo.z);
    if (d < best) { best = d; n = vec3<f32>(0.0, 0.0, -1.0); }
    d = abs(p.z - b.hi.z);
    if (d < best) { best = d; n = vec3<f32>(0.0, 0.0, 1.0); }
    return n;
}

fn wpos_from_depth(uv: vec2<f32>, d: f32) -> vec3<f32> {
    let ndc = vec4<f32>(uv.x * 2.0 - 1.0, 1.0 - uv.y * 2.0, d, 1.0);
    let h = rp.inv_vp * ndc;
    return h.xyz / max(h.w, 1e-5);
}

// ---------- fragment ----------

struct FSOut {
    @location(0) out0: vec4<f32>,
    @location(1) out1: vec4<f32>,
};

@fragment
fn fs(in: VSOut) -> FSOut {
    var o: FSOut;
    o.out0 = vec4<f32>(1.0, 1.0, 1.0, 1.0);
    o.out1 = vec4<f32>(0.0, 0.0, 0.0, 1.0);

    let rt_dims = vec2<f32>(rp.dims.x, rp.dims.y);
    let px = vec2<i32>(in.pos.xy);
    let uv = (vec2<f32>(px) + vec2<f32>(0.5, 0.5)) / rt_dims;
    let dsize = vec2<i32>(i32(rp.dims.z), i32(rp.dims.w));
    let dsize1 = dsize - vec2<i32>(1, 1);
    let dpx = clamp(vec2<i32>(uv * vec2<f32>(rp.dims.z, rp.dims.w)), vec2<i32>(0, 0), dsize1);

    let d0 = textureLoad(depth_tex, dpx, 0);
    if (d0 >= 0.99995) {
        return o; // pas de géométrie -> identité
    }
    let p = wpos_from_depth(uv, d0);

    // Normale par différences de profondeur (voisins droite / bas).
    let dpx_r = clamp(dpx + vec2<i32>(1, 0), vec2<i32>(0, 0), dsize1);
    let dpx_d = clamp(dpx + vec2<i32>(0, 1), vec2<i32>(0, 0), dsize1);
    let uv_r = (vec2<f32>(dpx_r) + vec2<f32>(0.5, 0.5)) / vec2<f32>(rp.dims.z, rp.dims.w);
    let uv_d = (vec2<f32>(dpx_d) + vec2<f32>(0.5, 0.5)) / vec2<f32>(rp.dims.z, rp.dims.w);
    let d1 = textureLoad(depth_tex, dpx_r, 0);
    let d2 = textureLoad(depth_tex, dpx_d, 0);
    var n = vec3<f32>(0.0, 1.0, 0.0);
    if (d1 < 0.99995 && d2 < 0.99995) {
        let pr = wpos_from_depth(uv_r, d1);
        let pd = wpos_from_depth(uv_d, d2);
        let cn = normalize(cross(pr - p, pd - p));
        if (dot(cn, rp.cam_pos.xyz - p) > 0.0) {
            n = cn;
        }
    }

    // ---- Ombres des néons (moyenne pondérée par leur contribution) ----
    let nl_count = u32(u.misc.x);
    var sum_w = 0.0;
    var sum_wv = 0.0;
    for (var i = 0u; i < 24u; i = i + 1u) {
        if (i >= nl_count) { break; }
        let lp = u.light_pos[i];
        let lc = u.light_col[i];
        if (lc.w <= 0.01) { continue; }
        let to = lp.xyz - p;
        let dist = length(to);
        if (dist > lp.w || dist < 0.05) { continue; }
        let att = smoothstep(lp.w, lp.w * 0.2, dist);
        let w = lc.w * att * att * max(dot(n, to / max(dist, 0.001)), 0.0);
        if (w <= 0.004) { continue; }
        // Jitter stable par pixel/lumière : pénombre sans scintillement.
        // ±0.12 max : sous un plafond à 3.0 m (lumière à 2.85), un jitter
        // plus large ferait piquer les rayons dans la dalle → néon à moitié
        // auto-ombré = halos disparus.
        let j = (hash3(vec3<f32>(f32(px.x), f32(px.y), f32(i) * 7.31)) - vec3<f32>(0.5)) * 0.24;
        let lt = lp.xyz + j;
        let vis = shadow_ray_light(p + n * 0.012, normalize(lt - p), distance(p, lt) - 0.2, lt);
        sum_w = sum_w + w;
        sum_wv = sum_wv + w * vis;
    }
    let sh_static = select(1.0, sum_wv / max(sum_w, 1e-4), sum_w > 1e-4);

    // ---- Ombre de la torche (déterministe) ----
    var sh_flash = 1.0;
    if (u.flash_col.w > 0.001) {
        let to = p - u.flash_pos.xyz;
        let dist = max(length(to), 0.001);
        let dir = to / dist;
        let cos_a = dot(dir, normalize(u.flash_dir.xyz));
        if (cos_a > u.misc.w - 0.02 && dist < 15.0) {
            sh_flash = shadow_ray(p + n * 0.012, -dir, dist - 0.1);
        }
    }

    // ---- AO + rebond (1 rayon en Qualité, 3 en Ultra) ----
    // Plancher de lisibilité : l'AO ne descend jamais sous 0.45 — avant, une
    // scène sans lumière partait au noir absolu (« on voit rien »).
    let ao_radius = rp.counts.w;
    let ao_samples = u32(max(rp.misc.z, 1.0));
    var ao_acc = 0.0;
    var gi = vec3<f32>(0.0, 0.0, 0.0);
    let up = select(vec3<f32>(0.0, 0.0, 1.0), vec3<f32>(1.0, 0.0, 0.0), abs(n.y) > 0.9);
    let t_dir = normalize(cross(n, up));
    let b_dir = cross(n, t_dir);
    for (var s = 0u; s < ao_samples; s = s + 1u) {
        let u1 = hash1(vec3<f32>(f32(px.x) * 1.13, f32(px.y) * 1.27, 3.1 + f32(s) * 17.73));
        let u2 = hash1(vec3<f32>(f32(px.x) * 1.71, f32(px.y) * 1.93, 9.4 + f32(s) * 23.31));
        let ang = u1 * 6.2831853;
        let rr = sqrt(u2);
        let local = vec3<f32>(cos(ang) * rr, sin(ang) * rr, sqrt(max(1.0 - u2, 0.0)));
        let dir_w = normalize(t_dir * local.x + b_dir * local.y + n * local.z);
        var hn = vec3<f32>(0.0, 1.0, 0.0);
        let t = trace(p + n * 0.012, dir_w, ao_radius, &hn);
        if (t >= 0.0) {
            let occ = clamp(t / ao_radius, 0.0, 1.0);
            ao_acc = ao_acc + occ * occ; // rapproche le profil d'un AO multi-échantillons
            // Rebond approximatif : depuis le point touché, contribution des néons.
            if (rp.misc.x > 0.001) {
                let hp2 = p + dir_w * t + hn * 0.01;
                for (var i = 0u; i < 24u; i = i + 1u) {
                    if (i >= nl_count) { break; }
                    let lp = u.light_pos[i];
                    let lc = u.light_col[i];
                    if (lc.w <= 0.01) { continue; }
                    let tol = lp.xyz - hp2;
                    let dl = length(tol);
                    if (dl > lp.w) { continue; }
                    let attl = smoothstep(lp.w, lp.w * 0.2, dl);
                    gi = gi + lc.rgb * lc.w * attl * attl * max(dot(hn, tol / max(dl, 0.001)), 0.0);
                }
            }
        } else {
            ao_acc = ao_acc + 1.0; // rayon perdu : pas d'occlusion
        }
    }
    var ao = ao_acc / f32(ao_samples);
    ao = 0.45 + 0.55 * ao;
    gi = gi * rp.misc.x * 0.5 / f32(ao_samples);

    // ---- Réflexions : PLEINE SCÈNE + néons sur sols polis + Fresnel ----
    // Le rayon miroir trace VRAIMENT la scène : le couloir (murs, portes,
    // baies serveurs) se reflète dans le lino ciré, la lumière dominante et
    // la torche sont ré-éclairées au point réfléchi — le « wow » du RT.
    var refl = vec3<f32>(0.0, 0.0, 0.0);
    let vdir = normalize(p - rp.cam_pos.xyz);
    let ndv = max(dot(n, -vdir), 0.0);
    let fres = 0.04 + 0.96 * pow(1.0 - ndv, 5.0); // Schlick
    let polished = select(0.0, 1.0, n.y > 0.5);   // sols (lino ciré) : reflets forts
    let rk = clamp(polished * 0.85 + fres, 0.0, 1.0);
    if (rk > 0.03) {
        let rdir = reflect(vdir, n);
        let ro2 = p + n * 0.012;

        // 1) Réflexion pleine scène : on trace le rayon miroir contre tous les
        //    AABB et on ré-éclaire le point touché (ambiance + néons + torche).
        var hn2 = vec3<f32>(0.0, 1.0, 0.0);
        let tr = trace(ro2, rdir, 34.0, &hn2);
        if (tr >= 0.0) {
            let hp = ro2 + rdir * tr;
            var lit = vec3<f32>(0.035, 0.04, 0.055); // ambiance du lieu réfléchi
            var best_w = 0.0;
            var best_i = 0u;
            for (var i = 0u; i < 24u; i = i + 1u) {
                if (i >= nl_count) { break; }
                let lp = u.light_pos[i];
                let lc = u.light_col[i];
                if (lc.w <= 0.01) { continue; }
                let to = lp.xyz - hp;
                let dl = length(to);
                if (dl > lp.w) { continue; }
                let att = smoothstep(lp.w, lp.w * 0.2, dl);
                let nl2 = max(dot(hn2, to / max(dl, 0.001)), 0.0);
                let w = lc.w * att * att * nl2;
                lit = lit + lc.rgb * w;
                if (w > best_w) { best_w = w; best_i = i; }
            }
            // Ombre portée uniquement pour la lumière dominante (perf : 1 rayon).
            if (best_w > 0.02) {
                let lpb = u.light_pos[best_i];
                let to = lpb.xyz - hp;
                let dl = max(length(to), 0.001);
                let vis = shadow_ray_light(hp + hn2 * 0.012, to / dl, dl - 0.2, lpb.xyz);
                lit = lit - u.light_col[best_i].rgb * best_w * (1.0 - vis);
            }
            // La torche se reflète aussi : traînée lumineuse sur sols brillants.
            if (u.flash_col.w > 0.001) {
                let tf = hp - u.flash_pos.xyz;
                let df = max(length(tf), 0.001);
                let dirf = tf / df;
                let cosf = dot(dirf, normalize(u.flash_dir.xyz));
                if (cosf > u.misc.w - 0.02 && df < 15.0) {
                    let spotf = smoothstep(u.misc.w, u.flash_dir.w, cosf);
                    let nlf = max(dot(hn2, -dirf), 0.0);
                    let attf = clamp(1.0 - df / 15.0, 0.0, 1.0);
                    let visf = shadow_ray(hp + hn2 * 0.012, -dirf, df - 0.1);
                    lit = lit + u.flash_col.rgb * u.flash_col.w * spotf * nlf * attf * attf * 1.7 * visf;
                }
            }
            // Fondu avec la distance : le reflet s'évanouit dans le brouillard.
            let fade = exp(-0.045 * tr);
            refl = refl + lit * 0.38 * fade * rk;
        }

        // 2) Reflets spéculaires des néons (sphères émissives pendants) —
        //    cône gloss élargi sur les sols : traînées plus larges et vivantes.
        let cone = select(0.86, 0.78, n.y > 0.5);
        var spec = vec3<f32>(0.0, 0.0, 0.0);
        for (var i = 0u; i < 24u; i = i + 1u) {
            if (i >= nl_count) { break; }
            let lp = u.light_pos[i];
            let lc = u.light_col[i];
            if (lc.w <= 0.01) { continue; }
            // Le néon pend juste sous le plafond : sphère émissive ~0.45 m.
            let sc = lp.xyz - vec3<f32>(0.0, 0.18, 0.0);
            let to = sc - ro2;
            let ds = length(to);
            if (ds > 26.0 || ds < 0.3) { continue; }
            let ldir = to / ds;
            let align = dot(ldir, rdir);
            if (align < cone) { continue; } // cône gloss autour du rayon miroir
            // Occlusion : un mur entre le sol et le néon casse le reflet
            // (on ignore la boîte du luminaire : auto-ombre sinon).
            if (shadow_ray_light(ro2, ldir, ds - 0.5, sc) < 0.5) { continue; }
            let glow = lc.rgb * lc.w * (1.0 - clamp(ds / 26.0, 0.0, 1.0) * 0.65);
            spec = spec + glow * smoothstep(cone, 1.0, align);
        }
        refl = refl + spec * 1.8;
    }

    o.out0 = vec4<f32>(ao, sh_static, sh_flash, 1.0);
    o.out1 = vec4<f32>(gi + refl, 1.0);
    return o;
}
