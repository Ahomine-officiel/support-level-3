//! Renderer wgpu : pipeline monde (instances + matériaux), post-process, UI.
//! Ray tracing optionnel : pré-pass profondeur + passe de rayons (rt.wgsl)
//! contre la scène AABB (rtscene.rs), appliquée dans world.wgsl.

pub mod model;
pub mod rtscene;
pub mod texture;
pub mod ui;
pub use ui::UiOp;

use model::{Model, Vertex};
use sl3_shared::map::MapData;
use std::collections::HashMap;
use winit::window::Window;
use wgpu::util::DeviceExt;

pub const MAX_LIGHTS: usize = 24;
#[repr(C)]
#[derive(Copy, Clone, bytemuck::Pod, bytemuck::Zeroable)]
pub struct WorldUniform {
    pub view_proj: [[f32; 4]; 4],
    pub cam_pos: [f32; 4],
    pub light_pos: [[f32; 4]; MAX_LIGHTS],
    pub light_col: [[f32; 4]; MAX_LIGHTS],
    pub flash_pos: [f32; 4],
    pub flash_dir: [f32; 4],
    pub misc: [f32; 4],
    pub flash_col: [f32; 4],
    /// Ambiance : x = calme (1 au début → 0 en horreur), y = peur, z,w libre.
    pub mood: [f32; 4],
}

#[repr(C)]
#[derive(Copy, Clone, bytemuck::Pod, bytemuck::Zeroable)]
pub struct InstanceRaw {
    pub m: [[f32; 4]; 4],
    pub emissive: [f32; 4],
    pub tint: [f32; 4],
}

pub const INSTANCE_LAYOUT: wgpu::VertexBufferLayout<'static> = wgpu::VertexBufferLayout {
    array_stride: std::mem::size_of::<InstanceRaw>() as u64,
    step_mode: wgpu::VertexStepMode::Instance,
    attributes: &[
        wgpu::VertexAttribute { offset: 0, shader_location: 3, format: wgpu::VertexFormat::Float32x4 },
        wgpu::VertexAttribute { offset: 16, shader_location: 4, format: wgpu::VertexFormat::Float32x4 },
        wgpu::VertexAttribute { offset: 32, shader_location: 5, format: wgpu::VertexFormat::Float32x4 },
        wgpu::VertexAttribute { offset: 48, shader_location: 6, format: wgpu::VertexFormat::Float32x4 },
        wgpu::VertexAttribute { offset: 64, shader_location: 7, format: wgpu::VertexFormat::Float32x4 },
        wgpu::VertexAttribute { offset: 80, shader_location: 8, format: wgpu::VertexFormat::Float32x4 },
    ],
};

#[derive(Clone)]
pub struct InstanceData {
    pub model: glam::Mat4,
    pub emissive: [f32; 4],
    pub tint: [f32; 4],
}

impl InstanceData {
    pub fn new(model: glam::Mat4) -> Self {
        InstanceData { model, emissive: [1.0, 1.0, 1.0, 1.0], tint: [1.0, 1.0, 1.0, 1.0] }
    }
    pub fn with_emissive(mut self, e: [f32; 4]) -> Self {
        self.emissive = e;
        self
    }
    pub fn with_tint(mut self, t: [f32; 4]) -> Self {
        self.tint = t;
        self
    }
    fn raw(&self) -> InstanceRaw {
        InstanceRaw {
            m: self.model.to_cols_array_2d(),
            emissive: self.emissive,
            tint: self.tint,
        }
    }
}

/// (fichier texture sans extension, force émissive du matériau).
pub fn material_def(name: &str) -> (String, f32) {
    let strength = match name {
        "led_strip" => 2.0,
        "screen_on" => 0.8,
        "terminal_screen" => 0.9,
        "exit_sign" => 1.4,
        "eyes" => 2.6,
        "light_panel" => 1.25,
        "battery" => 1.4,
        "receipt_paper" => 0.05,
        "poster_a" | "poster_b" | "poster_c" | "poster_d" => 0.04,
        "entity_mask" => 0.03,
        _ => 0.0,
    };
    (name.to_string(), strength)
}

#[derive(PartialEq, Eq, Hash, Clone)]
pub struct PartKey {
    pub model: String,
    pub part: usize,
}

pub struct StaticBatch {
    pub key: PartKey,
    pub buffer: wgpu::Buffer,
    pub count: u32,
}

/// Uniform de la passe de ray tracing (miroir de shaders/rt.wgsl).
#[repr(C)]
#[derive(Copy, Clone, bytemuck::Pod, bytemuck::Zeroable)]
pub struct RtParams {
    pub inv_vp: [[f32; 4]; 4],
    pub cam_pos: [f32; 4],
    /// x,y : taille tampon RT · z,w : taille texture profondeur.
    pub dims: [f32; 4],
    /// x : boîtes statiques · y : dynamiques · z : lumières · w : rayon AO (m).
    pub counts: [f32; 4],
    /// x : force GI (0 = désactivée) · y : AO appliquée à la lumière directe.
    pub misc: [f32; 4],
    /// Path tracing : x : rayons GI par pixel · y : rebonds · z : budget ombres
    /// (0 = sans ombre, 1 = lumière dominante, 2 = toutes les lumières) · w : échantillons de réflexion.
    pub pt: [f32; 4],
}

/// Données par frame nécessaires au ray tracing (None = RT désactivé).
pub struct RtFrame<'a> {
    pub inv_vp: [[f32; 4]; 4],
    pub dyn_boxes: &'a [rtscene::GpuAabb],
}

/// Données par frame pour l'upscaling temporel (None = chemin natif).
pub struct UpsFrame {
    /// inverse(proj * vue) de la frame courante (jitterée), pour les vecteurs de mouvement.
    pub inv_vp: [[f32; 4]; 4],
}

/// Uniform des passes d'upscaling (miroir de shaders/upscale.wgsl).
#[repr(C)]
#[derive(Copy, Clone, bytemuck::Pod, bytemuck::Zeroable)]
pub struct UpsParams {
    pub display_size: [f32; 4],
    pub render_size: [f32; 4],
    pub jitter: [f32; 4],
    pub inv_vp_cur: [[f32; 4]; 4],
    pub vp_prev: [[f32; 4]; 4],
}

pub struct StaticBatches {
    pub batches: Vec<StaticBatch>,
    pub total_instances: usize,
}

/// Batches d'instances dynamiques reconstruits chaque frame (même mécanisme
/// que les statiques : un buffer par part, créé hors encoder).
pub struct DynBatches {
    /// (clé de part, offset en octets dans le buffer d'origine, instances)
    pub plan: Vec<(PartKey, u64, u32)>,
    /// (clé de part, buffer d'instances, instances)
    pub batches: Vec<(PartKey, wgpu::Buffer, u32)>,
    pub max_end: u64,
}

pub struct Renderer {
    pub device: wgpu::Device,
    pub queue: wgpu::Queue,
    surface: wgpu::Surface<'static>,
    surface_config: wgpu::SurfaceConfiguration,
    pub window: std::sync::Arc<Window>,
    pub models: HashMap<String, Model>,

    world_pipeline: wgpu::RenderPipeline,
    world_bind0: wgpu::BindGroup,
    world_uniform_buf: wgpu::Buffer,
    material_bind_groups: HashMap<String, wgpu::BindGroup>,

    post_pipeline: wgpu::RenderPipeline,
    post_bind: wgpu::BindGroup,
    post_uniform_buf: wgpu::Buffer,
    offscreen_view: wgpu::TextureView,
    offscreen_tex: wgpu::Texture,
    depth_view: wgpu::TextureView,
    depth_tex: wgpu::Texture,
    /// Échelle de rendu dynamique (1.0 = pleine résolution, 0.45 min) — iGPU friendly.
    render_scale: f32,

    // ----- Upscaling temporel (FSR 3 / DLSS) -----
    /// 0 = natif, 1 = FSR 3 (upscaling temporel), 2 = DLSS (même noyau, RTX requis).
    pub upscaler: u8,
    /// 0 = qualité (x1.5), 1 = équilibré (x1.7), 2 = performance (x2.0).
    upscale_quality: u8,
    /// Multiplicateur interne du preset (1.0 en natif).
    ups_scale: f32,
    /// Netteté RCAS (stops ; grand = plus doux).
    rcas_stops: f32,
    mv_pipeline: wgpu::RenderPipeline,
    dilate_pipeline: wgpu::RenderPipeline,
    accum_pipeline: wgpu::RenderPipeline,
    rcas_pipeline: wgpu::RenderPipeline,
    mv_bind_layout: wgpu::BindGroupLayout,
    dilate_bind_layout: wgpu::BindGroupLayout,
    accum_bind_layout: wgpu::BindGroupLayout,
    rcas_bind_layout: wgpu::BindGroupLayout,
    mv_bind: wgpu::BindGroup,
    dilate_bind: wgpu::BindGroup,
    accum_bind: wgpu::BindGroup,
    rcas_bind: wgpu::BindGroup,
    ups_uniform_buf: wgpu::Buffer,
    post_tex: wgpu::Texture,
    post_view: wgpu::TextureView,
    mv_tex: wgpu::Texture,
    mv_view: wgpu::TextureView,
    mv_dil_tex: wgpu::Texture,
    mv_dil_view: wgpu::TextureView,
    hist_texs: [wgpu::Texture; 2],
    hist_views: [wgpu::TextureView; 2],
    hist_idx: usize,
    prev_vp: Option<[[f32; 4]; 4]>,
    frame_idx: u32,
    /// Jitter courant en pixels internes (x, -y) pour l'uniform shader.
    jitter_px: [f32; 2],
    /// Historique temporel à invalider (changement de taille/mode/qualité/début de partie).
    pub reset_upscale: bool,

    ui_pipeline: wgpu::RenderPipeline,
    ui_bind0: wgpu::BindGroup,
    ui_uniform_buf: wgpu::Buffer,
    pub font_bg: wgpu::BindGroup,
    pub white_bg: wgpu::BindGroup,
    pub font: ui::FontData,
    ui_buf: wgpu::Buffer,
    /// Index buffer UI : motif (0,1,2, 1,3,2) répété — un quad = 4 sommets consécutifs.
    ui_index_buf: wgpu::Buffer,
    /// Capacité (en quads) de ui_index_buf — agrandie au besoin comme ui_buf.
    ui_index_cap: u32,

    // ----- Capture d'écran (autopilot / [F12]) -----
    /// Si défini : la frame courante est rendue dans une texture dédiée puis
    /// écrite en PNG à ce chemin (une seule fois).
    pub capture_path: Option<std::path::PathBuf>,
    capture_tex: Option<wgpu::Texture>,

    // ----- Ray tracing optionnel -----
    /// 0 = désactivé, 1 = qualité (ombres + AO), 2 = ultra (+ GI 2 rebonds), 3 = overdrive (path tracing).
    pub rt_mode: u8,
    /// Échelle du tampon RT relativement à la SURFACE native (pas au tampon
    /// monde : DRS et FSR 3 se multipliaient en cascade avec cette échelle).
    rt_scale: f32,
    world_bind_layout: wgpu::BindGroupLayout,
    world_pipeline_rt: wgpu::RenderPipeline,
    prepass_pipeline: wgpu::RenderPipeline,
    rt_pipeline: wgpu::RenderPipeline,
    rt_bind_layout: wgpu::BindGroupLayout,
    rt_bind: wgpu::BindGroup,
    rt_params_buf: wgpu::Buffer,
    rt_static_buf: wgpu::Buffer,
    rt_dyn_buf: wgpu::Buffer,
    rt_static_count: u32,
    rt0_tex: wgpu::Texture,
    rt1_tex: wgpu::Texture,
    rt0_view: wgpu::TextureView,
    rt1_view: wgpu::TextureView,
    rt_neutral0: wgpu::TextureView,
    rt_neutral1: wgpu::TextureView,
    /// Nom de l'adaptateur GPU détecté (pour l'auto-configuration RT).
    pub adapter_name: String,
}

impl Renderer {
    pub fn new(window: std::sync::Arc<Window>) -> Renderer {
        let size = window.inner_size();
        let instance = wgpu::Instance::new(wgpu::InstanceDescriptor::default());
        let surface = instance
            .create_surface(window.clone())
            .expect("création surface");
        let adapter = pollster::block_on(instance.request_adapter(&wgpu::RequestAdapterOptions {
            power_preference: wgpu::PowerPreference::HighPerformance,
            compatible_surface: Some(&surface),
            force_fallback_adapter: false,
        }))
        .expect("pas de GPU compatible (Vulkan/Metal/DX12 requis)");
        let adapter_info = adapter.get_info();
        let adapter_name = if adapter_info.name.is_empty() {
            format!("{:?}", adapter_info.backend)
        } else {
            format!("{} ({:?})", adapter_info.name, adapter_info.backend)
        };

        let (device, queue) = pollster::block_on(adapter.request_device(
            &wgpu::DeviceDescriptor {
                label: Some("sl3-device"),
                required_features: wgpu::Features::empty(),
                required_limits: wgpu::Limits::default(),
                memory_hints: wgpu::MemoryHints::Performance,
            },
            None,
        ))
        .expect("création device");

        // Les erreurs wgpu sans handler sont avalées en silence : les rendre visibles.
        device.on_uncaptured_error(Box::new(|e| {
            eprintln!("[wgpu-error] {e}");
        }));

        let caps = surface.get_capabilities(&adapter);
        let format = caps
            .formats
            .iter()
            .find(|f| f.is_srgb())
            .copied()
            .unwrap_or(caps.formats[0]);
        let surface_config = wgpu::SurfaceConfiguration {
            usage: wgpu::TextureUsages::RENDER_ATTACHMENT,
            format,
            width: size.width.max(1),
            height: size.height.max(1),
            present_mode: wgpu::PresentMode::Fifo,
            alpha_mode: caps.alpha_modes[0],
            view_formats: vec![],
            desired_maximum_frame_latency: 2,
        };
        surface.configure(&device, &surface_config);

        // Modèles + matériaux.
        let models = model::load_all_models(&device);
        let mut material_bind_groups = HashMap::new();
        let mat_layout = Self::material_layout(&device);
        for name in [
            "concrete", "concrete_dark", "floor_hall", "floor_corridor", "floor_office",
            "floor_server", "floor_arch", "floor_elec", "ceiling", "metal_dark",
            "rack_front", "server_front", "led_strip", "screen_off", "screen_on",
            "terminal_screen", "desk_wood", "terminal_body", "chair_fabric", "door_metal",
            "door_frame", "shelf_metal", "cardboard", "entity_cloth", "entity_mask",
            "eyes", "tech_vest", "tech_pants", "tech_head", "receipt_paper",
            "breaker_panel", "exit_sign", "battery", "extinguisher", "duct",
            "light_panel", "hazard", "poster_a", "poster_b", "poster_c", "poster_d",
        ] {
            let (file, strength) = material_def(name);
            let tex = texture::load_png(&device, &queue, &format!("textures/{file}.png"));
            let mat_buf = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
                label: None,
                contents: bytemuck::cast_slice(&[1.0f32, 1.0, 1.0, strength]),
                usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
            });
            let bg = device.create_bind_group(&wgpu::BindGroupDescriptor {
                label: Some(name),
                layout: &mat_layout,
                entries: &[
                    wgpu::BindGroupEntry { binding: 0, resource: wgpu::BindingResource::Sampler(&Self::world_sampler(&device)) },
                    wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::TextureView(&tex.view) },
                    wgpu::BindGroupEntry { binding: 2, resource: mat_buf.as_entire_binding() },
                ],
            });
            material_bind_groups.insert(name.to_string(), bg);
        }

        // Uniforms monde.
        let world_uniform_buf = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some("world-uniform"),
            contents: bytemuck::bytes_of(&WorldUniform {
                view_proj: glam::Mat4::IDENTITY.to_cols_array_2d(),
                cam_pos: [0.0; 4],
                light_pos: [[0.0; 4]; MAX_LIGHTS],
                light_col: [[0.0; 4]; MAX_LIGHTS],
                flash_pos: [0.0; 4],
                flash_dir: [0.0; 4],
                misc: [0.0; 4],
                flash_col: [0.0; 4],
                mood: [1.0, 0.0, 0.0, 0.0],
            }),
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
        });
        let world_bind_layout = Self::world_bind_layout(&device);
        // Textures RT neutres (RT désactivé) : AO=1, ombres=1, GI=0 -> rendu identique.
        let n0 = texture::neutral_rt_texture(&device, &queue, "rt-neutral0", [0x3C00, 0x3C00, 0x0000, 0x3C00]);
        let n1 = texture::neutral_rt_texture(&device, &queue, "rt-neutral1", [0x0000, 0x0000, 0x0000, 0x3C00]);
        let rt_neutral0 = n0.view;
        let rt_neutral1 = n1.view;
        let world_bind0 = Self::make_world_bind0(&device, &world_bind_layout, &world_uniform_buf, &rt_neutral0, &rt_neutral1);

        let world_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("world.wgsl"),
            source: wgpu::ShaderSource::Wgsl(include_str!("../shaders/world.wgsl").into()),
        });
        let world_pipeline = Self::world_pipeline_with(
            &device, &world_bind_layout, &mat_layout, &world_shader, format,
            true, wgpu::CompareFunction::Less,
        );
        // Variante RT : profondeur déjà écrite par la pré-pass -> test large, écriture off.
        let world_pipeline_rt = Self::world_pipeline_with(
            &device, &world_bind_layout, &mat_layout, &world_shader, format,
            false, wgpu::CompareFunction::LessEqual,
        );
        let prepass_pipeline = Self::prepass_pipeline(&device, &world_bind_layout, &mat_layout, &world_shader);

        // Post-process.
        let post_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("post.wgsl"),
            source: wgpu::ShaderSource::Wgsl(include_str!("../shaders/post.wgsl").into()),
        });
        let post_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("post-layout"),
            entries: &[
                wgpu::BindGroupLayoutEntry { binding: 0, visibility: wgpu::ShaderStages::FRAGMENT, ty: wgpu::BindingType::Buffer { ty: wgpu::BufferBindingType::Uniform, has_dynamic_offset: false, min_binding_size: None }, count: None },
                wgpu::BindGroupLayoutEntry { binding: 1, visibility: wgpu::ShaderStages::FRAGMENT, ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering), count: None },
                wgpu::BindGroupLayoutEntry { binding: 2, visibility: wgpu::ShaderStages::FRAGMENT, ty: wgpu::BindingType::Texture { sample_type: wgpu::TextureSampleType::Float { filterable: true }, multisampled: false, view_dimension: wgpu::TextureViewDimension::D2 }, count: None },
            ],
        });
        let post_uniform_buf = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some("post-uniform"),
            contents: bytemuck::cast_slice(&[0.0f32; 4]),
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
        });

        let (offscreen_tex, offscreen_view) = Self::make_offscreen(&device, size.width.max(1), size.height.max(1), format);
        let (depth_tex, depth_view) = Self::make_depth(&device, size.width.max(1), size.height.max(1));
        let post_bind = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("post-bind"),
            layout: &post_layout,
            entries: &[
                wgpu::BindGroupEntry { binding: 0, resource: post_uniform_buf.as_entire_binding() },
                wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::Sampler(&texture::linear_sampler(&device, false)) },
                wgpu::BindGroupEntry { binding: 2, resource: wgpu::BindingResource::TextureView(&offscreen_view) },
            ],
        });
        let post_pipeline = Self::post_pipeline(&device, &post_layout, &post_shader, format);

        // ----- Ray tracing : shader, pipeline, buffers, bind group -----
        let rt_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("rt.wgsl"),
            source: wgpu::ShaderSource::Wgsl(include_str!("../shaders/rt.wgsl").into()),
        });
        let rt_bind_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("rt-layout"),
            entries: &[
                wgpu::BindGroupLayoutEntry { binding: 0, visibility: wgpu::ShaderStages::FRAGMENT, ty: wgpu::BindingType::Buffer { ty: wgpu::BufferBindingType::Uniform, has_dynamic_offset: false, min_binding_size: None }, count: None },
                wgpu::BindGroupLayoutEntry { binding: 1, visibility: wgpu::ShaderStages::FRAGMENT, ty: wgpu::BindingType::Buffer { ty: wgpu::BufferBindingType::Uniform, has_dynamic_offset: false, min_binding_size: None }, count: None },
                wgpu::BindGroupLayoutEntry { binding: 2, visibility: wgpu::ShaderStages::FRAGMENT, ty: wgpu::BindingType::Buffer { ty: wgpu::BufferBindingType::Storage { read_only: true }, has_dynamic_offset: false, min_binding_size: None }, count: None },
                wgpu::BindGroupLayoutEntry { binding: 3, visibility: wgpu::ShaderStages::FRAGMENT, ty: wgpu::BindingType::Buffer { ty: wgpu::BufferBindingType::Storage { read_only: true }, has_dynamic_offset: false, min_binding_size: None }, count: None },
                wgpu::BindGroupLayoutEntry { binding: 4, visibility: wgpu::ShaderStages::FRAGMENT, ty: wgpu::BindingType::Texture { sample_type: wgpu::TextureSampleType::Depth, multisampled: false, view_dimension: wgpu::TextureViewDimension::D2 }, count: None },
            ],
        });
        let rt_pipeline = Self::rt_pipeline(&device, &rt_bind_layout, &rt_shader);
        let rt_params_buf = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("rt-params"),
            size: std::mem::size_of::<RtParams>() as u64,
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        let rt_static_buf = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("rt-static-boxes"),
            size: (rtscene::MAX_RT_STATIC_BOXES * std::mem::size_of::<rtscene::GpuAabb>()) as u64,
            usage: wgpu::BufferUsages::STORAGE | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        let rt_dyn_buf = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("rt-dyn-boxes"),
            size: (rtscene::MAX_RT_DYN_BOXES * std::mem::size_of::<rtscene::GpuAabb>()) as u64,
            usage: wgpu::BufferUsages::STORAGE | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        let (rt0_tex, rt0_view) = Self::make_rt_target(&device, 1, 1, "rt0");
        let (rt1_tex, rt1_view) = Self::make_rt_target(&device, 1, 1, "rt1");
        let rt_bind = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("rt-bind"),
            layout: &rt_bind_layout,
            entries: &[
                wgpu::BindGroupEntry { binding: 0, resource: rt_params_buf.as_entire_binding() },
                wgpu::BindGroupEntry { binding: 1, resource: world_uniform_buf.as_entire_binding() },
                wgpu::BindGroupEntry { binding: 2, resource: rt_static_buf.as_entire_binding() },
                wgpu::BindGroupEntry { binding: 3, resource: rt_dyn_buf.as_entire_binding() },
                wgpu::BindGroupEntry { binding: 4, resource: wgpu::BindingResource::TextureView(&depth_view) },
            ],
        });

        // UI.
        let ui_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("ui.wgsl"),
            source: wgpu::ShaderSource::Wgsl(include_str!("../shaders/ui.wgsl").into()),
        });
        let ui_layout0 = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("ui-layout0"),
            entries: &[wgpu::BindGroupLayoutEntry {
                binding: 0,
                visibility: wgpu::ShaderStages::VERTEX,
                ty: wgpu::BindingType::Buffer { ty: wgpu::BufferBindingType::Uniform, has_dynamic_offset: false, min_binding_size: None },
                count: None,
            }],
        });
        let ui_layout1 = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("ui-layout1"),
            entries: &[
                wgpu::BindGroupLayoutEntry { binding: 0, visibility: wgpu::ShaderStages::FRAGMENT, ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering), count: None },
                wgpu::BindGroupLayoutEntry { binding: 1, visibility: wgpu::ShaderStages::FRAGMENT, ty: wgpu::BindingType::Texture { sample_type: wgpu::TextureSampleType::Float { filterable: true }, multisampled: false, view_dimension: wgpu::TextureViewDimension::D2 }, count: None },
            ],
        });
        let ui_uniform_buf = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some("ui-uniform"),
            contents: bytemuck::cast_slice(&[size.width as f32, size.height as f32, 0.0, 0.0]),
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
        });
        let ui_bind0 = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("ui-bind0"),
            layout: &ui_layout0,
            entries: &[wgpu::BindGroupEntry { binding: 0, resource: ui_uniform_buf.as_entire_binding() }],
        });
        let white_tex = texture::white_texture(&device, &queue);
        let white_bg = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("ui-white"),
            layout: &ui_layout1,
            entries: &[
                wgpu::BindGroupEntry { binding: 0, resource: wgpu::BindingResource::Sampler(&texture::linear_sampler(&device, false)) },
                wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::TextureView(&white_tex.view) },
            ],
        });
        let (font_tex, font) = ui::load_font(&device, &queue);
        let font_bg = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("ui-font"),
            layout: &ui_layout1,
            entries: &[
                wgpu::BindGroupEntry { binding: 0, resource: wgpu::BindingResource::Sampler(&texture::linear_sampler(&device, false)) },
                wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::TextureView(&font_tex.view) },
            ],
        });
        let ui_pipeline = Self::ui_pipeline(&device, &ui_layout0, &ui_layout1, &ui_shader, format);
        let ui_buf = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("ui-verts"),
            size: (4 * 4096 * std::mem::size_of::<ui::UiVertex>() as u64).max(64),
            usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        // Index buffer UI : chaque quad de 4 sommets est déroulé en 2 triangles
        // (TL,TR,BL) + (TR,BR,BL) — sinon seuls les quads à 1 instance s'affichent.
        let mut ui_idx: Vec<u32> = Vec::with_capacity(4096 * 6);
        for q in 0..4096u32 {
            let v = q * 4;
            ui_idx.extend_from_slice(&[v, v + 1, v + 2, v + 1, v + 3, v + 2]);
        }
        let ui_index_buf = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some("ui-indices"),
            contents: bytemuck::cast_slice(&ui_idx),
            usage: wgpu::BufferUsages::INDEX,
        });

        // ----- Upscaling temporel (FSR 3 / DLSS) : pipelines + layouts -----
        let ups_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("upscale.wgsl"),
            source: wgpu::ShaderSource::Wgsl(include_str!("../shaders/upscale.wgsl").into()),
        });
        let uni_entry = || wgpu::BindGroupLayoutEntry {
            binding: 0,
            visibility: wgpu::ShaderStages::VERTEX | wgpu::ShaderStages::FRAGMENT,
            ty: wgpu::BindingType::Buffer { ty: wgpu::BufferBindingType::Uniform, has_dynamic_offset: false, min_binding_size: None },
            count: None,
        };
        let depth_entry = || wgpu::BindGroupLayoutEntry {
            binding: 1,
            visibility: wgpu::ShaderStages::FRAGMENT,
            ty: wgpu::BindingType::Texture { sample_type: wgpu::TextureSampleType::Depth, multisampled: false, view_dimension: wgpu::TextureViewDimension::D2 },
            count: None,
        };
        let ftexture = |binding: u32| wgpu::BindGroupLayoutEntry {
            binding,
            visibility: wgpu::ShaderStages::FRAGMENT,
            ty: wgpu::BindingType::Texture { sample_type: wgpu::TextureSampleType::Float { filterable: true }, multisampled: false, view_dimension: wgpu::TextureViewDimension::D2 },
            count: None,
        };
        let mv_bind_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("ups-mv-layout"),
            entries: &[uni_entry(), depth_entry()],
        });
        let dilate_bind_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("ups-dilate-layout"),
            entries: &[uni_entry(), depth_entry(), ftexture(4)],
        });
        let accum_bind_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("ups-accum-layout"),
            entries: &[
                uni_entry(),
                wgpu::BindGroupLayoutEntry { binding: 2, visibility: wgpu::ShaderStages::FRAGMENT, ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering), count: None },
                ftexture(3),
                ftexture(5),
                ftexture(6),
            ],
        });
        let rcas_bind_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("ups-rcas-layout"),
            entries: &[uni_entry(), ftexture(6)],
        });
        let mv_pipeline = Self::ups_pipeline(&device, &mv_bind_layout, &ups_shader, "fs_mv", wgpu::TextureFormat::Rg16Float);
        let dilate_pipeline = Self::ups_pipeline(&device, &dilate_bind_layout, &ups_shader, "fs_dilate", wgpu::TextureFormat::Rg16Float);
        let accum_pipeline = Self::ups_pipeline(&device, &accum_bind_layout, &ups_shader, "fs_accum", wgpu::TextureFormat::Rgba16Float);
        let rcas_pipeline = Self::ups_pipeline(&device, &rcas_bind_layout, &ups_shader, "fs_rcas", format);
        let ups_uniform_buf = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("ups-uniform"),
            size: std::mem::size_of::<UpsParams>() as u64,
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        // Textures provisoires 1x1 : recreate_all_targets() les dimensionne juste après.
        let mk1 = |label: &str, fmt: wgpu::TextureFormat| -> (wgpu::Texture, wgpu::TextureView) {
            let t = device.create_texture(&wgpu::TextureDescriptor {
                label: Some(label),
                size: wgpu::Extent3d { width: 1, height: 1, depth_or_array_layers: 1 },
                mip_level_count: 1,
                sample_count: 1,
                dimension: wgpu::TextureDimension::D2,
                format: fmt,
                usage: wgpu::TextureUsages::RENDER_ATTACHMENT | wgpu::TextureUsages::TEXTURE_BINDING,
                view_formats: &[],
            });
            let v = t.create_view(&wgpu::TextureViewDescriptor::default());
            (t, v)
        };
        let (post_tex, post_view) = mk1("ups-post", format);
        let (mv_tex, mv_view) = mk1("ups-mv", wgpu::TextureFormat::Rg16Float);
        let (mv_dil_tex, mv_dil_view) = mk1("ups-mv-dil", wgpu::TextureFormat::Rg16Float);
        let (h0, h0v) = mk1("ups-hist0", wgpu::TextureFormat::Rgba16Float);
        let (h1, h1v) = mk1("ups-hist1", wgpu::TextureFormat::Rgba16Float);
        let mk_bind = |layout: &wgpu::BindGroupLayout, entries: &[wgpu::BindGroupEntry]| {
            device.create_bind_group(&wgpu::BindGroupDescriptor {
                label: Some("ups-bind"),
                layout,
                entries,
            })
        };
        let uni_res = ups_uniform_buf.as_entire_binding();
        let mv_bind = mk_bind(&mv_bind_layout, &[
            wgpu::BindGroupEntry { binding: 0, resource: uni_res.clone() },
            wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::TextureView(&depth_view) },
        ]);
        let dilate_bind = mk_bind(&dilate_bind_layout, &[
            wgpu::BindGroupEntry { binding: 0, resource: uni_res.clone() },
            wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::TextureView(&depth_view) },
            wgpu::BindGroupEntry { binding: 4, resource: wgpu::BindingResource::TextureView(&mv_view) },
        ]);
        let accum_bind = mk_bind(&accum_bind_layout, &[
            wgpu::BindGroupEntry { binding: 0, resource: uni_res.clone() },
            wgpu::BindGroupEntry { binding: 2, resource: wgpu::BindingResource::Sampler(&texture::linear_sampler(&device, false)) },
            wgpu::BindGroupEntry { binding: 3, resource: wgpu::BindingResource::TextureView(&post_view) },
            wgpu::BindGroupEntry { binding: 5, resource: wgpu::BindingResource::TextureView(&mv_dil_view) },
            wgpu::BindGroupEntry { binding: 6, resource: wgpu::BindingResource::TextureView(&h0v) },
        ]);
        let rcas_bind = mk_bind(&rcas_bind_layout, &[
            wgpu::BindGroupEntry { binding: 0, resource: uni_res.clone() },
            wgpu::BindGroupEntry { binding: 6, resource: wgpu::BindingResource::TextureView(&h0v) },
        ]);

        let renderer_struct = Renderer {
            device,
            queue,
            surface,
            surface_config,
            window,
            models,
            world_pipeline,
            world_bind0,
            world_uniform_buf,
            material_bind_groups,
            post_pipeline,
            post_bind,
            post_uniform_buf,
            offscreen_view,
            offscreen_tex,
            depth_view,
            depth_tex,
            render_scale: 1.0,
            upscaler: 0,
            upscale_quality: 0,
            ups_scale: 1.0,
            rcas_stops: 2.0,
            mv_pipeline,
            dilate_pipeline,
            accum_pipeline,
            rcas_pipeline,
            mv_bind_layout,
            dilate_bind_layout,
            accum_bind_layout,
            rcas_bind_layout,
            mv_bind,
            dilate_bind,
            accum_bind,
            rcas_bind,
            ups_uniform_buf,
            post_tex,
            post_view,
            mv_tex,
            mv_view,
            mv_dil_tex,
            mv_dil_view,
            hist_texs: [h0, h1],
            hist_views: [h0v, h1v],
            hist_idx: 0,
            prev_vp: None,
            frame_idx: 0,
            jitter_px: [0.0, 0.0],
            reset_upscale: true,
            ui_pipeline,
            ui_bind0,
            ui_uniform_buf,
            font_bg,
            white_bg,
            font,
            ui_buf,
            ui_index_buf,
            ui_index_cap: 4096,
            capture_path: None,
            capture_tex: None,
            rt_mode: 0,
            rt_scale: 0.7,
            world_bind_layout,
            world_pipeline_rt,
            prepass_pipeline,
            rt_pipeline,
            rt_bind_layout,
            rt_bind,
            rt_params_buf,
            rt_static_buf,
            rt_dyn_buf,
            rt_static_count: 0,
            rt0_tex,
            rt1_tex,
            rt0_view,
            rt1_view,
            rt_neutral0,
            rt_neutral1,
            adapter_name,
        };
        let mut renderer = renderer_struct;
        renderer.recreate_all_targets();
        renderer
    }

    // ---------- helpers de création ----------
    fn world_sampler(device: &wgpu::Device) -> wgpu::Sampler {
        texture::linear_sampler(device, true)
    }

    fn world_bind_layout(device: &wgpu::Device) -> wgpu::BindGroupLayout {
        device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("world-layout0"),
            entries: &[
                wgpu::BindGroupLayoutEntry {
                    binding: 0,
                    visibility: wgpu::ShaderStages::VERTEX | wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Buffer { ty: wgpu::BufferBindingType::Uniform, has_dynamic_offset: false, min_binding_size: None },
                    count: None,
                },
                wgpu::BindGroupLayoutEntry { binding: 1, visibility: wgpu::ShaderStages::FRAGMENT, ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering), count: None },
                wgpu::BindGroupLayoutEntry { binding: 2, visibility: wgpu::ShaderStages::FRAGMENT, ty: wgpu::BindingType::Texture { sample_type: wgpu::TextureSampleType::Float { filterable: true }, multisampled: false, view_dimension: wgpu::TextureViewDimension::D2 }, count: None },
                wgpu::BindGroupLayoutEntry { binding: 3, visibility: wgpu::ShaderStages::FRAGMENT, ty: wgpu::BindingType::Texture { sample_type: wgpu::TextureSampleType::Float { filterable: true }, multisampled: false, view_dimension: wgpu::TextureViewDimension::D2 }, count: None },
            ],
        })
    }

    /// Bind group 0 du monde : uniform + sampler + textures RT (réelles ou neutres).
    fn make_world_bind0(
        device: &wgpu::Device,
        layout: &wgpu::BindGroupLayout,
        uniform_buf: &wgpu::Buffer,
        rt0: &wgpu::TextureView,
        rt1: &wgpu::TextureView,
    ) -> wgpu::BindGroup {
        let sampler = texture::linear_sampler(device, false);
        device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("world-bind0"),
            layout,
            entries: &[
                wgpu::BindGroupEntry { binding: 0, resource: uniform_buf.as_entire_binding() },
                wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::Sampler(&sampler) },
                wgpu::BindGroupEntry { binding: 2, resource: wgpu::BindingResource::TextureView(rt0) },
                wgpu::BindGroupEntry { binding: 3, resource: wgpu::BindingResource::TextureView(rt1) },
            ],
        })
    }

    fn material_layout(device: &wgpu::Device) -> wgpu::BindGroupLayout {
        device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("world-layout1"),
            entries: &[
                wgpu::BindGroupLayoutEntry { binding: 0, visibility: wgpu::ShaderStages::FRAGMENT, ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering), count: None },
                wgpu::BindGroupLayoutEntry { binding: 1, visibility: wgpu::ShaderStages::FRAGMENT, ty: wgpu::BindingType::Texture { sample_type: wgpu::TextureSampleType::Float { filterable: true }, multisampled: false, view_dimension: wgpu::TextureViewDimension::D2 }, count: None },
                wgpu::BindGroupLayoutEntry { binding: 2, visibility: wgpu::ShaderStages::FRAGMENT, ty: wgpu::BindingType::Buffer { ty: wgpu::BufferBindingType::Uniform, has_dynamic_offset: false, min_binding_size: None }, count: None },
            ],
        })
    }

    fn world_pipeline_with(
        device: &wgpu::Device,
        bind0: &wgpu::BindGroupLayout,
        bind1: &wgpu::BindGroupLayout,
        shader: &wgpu::ShaderModule,
        format: wgpu::TextureFormat,
        depth_write: bool,
        depth_compare: wgpu::CompareFunction,
    ) -> wgpu::RenderPipeline {
        let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("world-pll"),
            bind_group_layouts: &[bind0, bind1],
            push_constant_ranges: &[],
        });
        device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("world-pipeline"),
            layout: Some(&layout),
            vertex: wgpu::VertexState {
                module: shader,
                entry_point: "vs",
                buffers: &[Vertex::LAYOUT, INSTANCE_LAYOUT],
                compilation_options: Default::default(),
            },
            fragment: Some(wgpu::FragmentState {
                module: shader,
                entry_point: "fs",
                targets: &[Some(wgpu::ColorTargetState {
                    format,
                    blend: None,
                    write_mask: wgpu::ColorWrites::ALL,
                })],
                compilation_options: Default::default(),
            }),
            primitive: wgpu::PrimitiveState::default(),
            depth_stencil: Some(wgpu::DepthStencilState {
                format: wgpu::TextureFormat::Depth24Plus,
                depth_write_enabled: depth_write,
                depth_compare,
                stencil: Default::default(),
                bias: Default::default(),
            }),
            multisample: Default::default(),
            multiview: None,
            cache: None,
        })
    }

    /// Pré-pass profondeur (vertex seul) pour la passe de ray tracing.
    fn prepass_pipeline(device: &wgpu::Device, bind0: &wgpu::BindGroupLayout, bind1: &wgpu::BindGroupLayout, shader: &wgpu::ShaderModule) -> wgpu::RenderPipeline {
        let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("prepass-pll"),
            bind_group_layouts: &[bind0, bind1],
            push_constant_ranges: &[],
        });
        device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("prepass-pipeline"),
            layout: Some(&layout),
            vertex: wgpu::VertexState {
                module: shader,
                entry_point: "vs",
                buffers: &[Vertex::LAYOUT, INSTANCE_LAYOUT],
                compilation_options: Default::default(),
            },
            fragment: None,
            primitive: wgpu::PrimitiveState::default(),
            depth_stencil: Some(wgpu::DepthStencilState {
                format: wgpu::TextureFormat::Depth24Plus,
                depth_write_enabled: true,
                depth_compare: wgpu::CompareFunction::Less,
                stencil: Default::default(),
                bias: Default::default(),
            }),
            multisample: Default::default(),
            multiview: None,
            cache: None,
        })
    }

    /// Passe RT : fullscreen triangle, deux cibles rgba16float (MRT).
    fn rt_pipeline(device: &wgpu::Device, layout: &wgpu::BindGroupLayout, shader: &wgpu::ShaderModule) -> wgpu::RenderPipeline {
        let pll = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("rt-pll"),
            bind_group_layouts: &[layout],
            push_constant_ranges: &[],
        });
        device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("rt-pipeline"),
            layout: Some(&pll),
            vertex: wgpu::VertexState {
                module: shader,
                entry_point: "vs",
                buffers: &[],
                compilation_options: Default::default(),
            },
            fragment: Some(wgpu::FragmentState {
                module: shader,
                entry_point: "fs",
                targets: &[
                    Some(wgpu::ColorTargetState { format: wgpu::TextureFormat::Rgba16Float, blend: None, write_mask: wgpu::ColorWrites::ALL }),
                    Some(wgpu::ColorTargetState { format: wgpu::TextureFormat::Rgba16Float, blend: None, write_mask: wgpu::ColorWrites::ALL }),
                ],
                compilation_options: Default::default(),
            }),
            primitive: wgpu::PrimitiveState { cull_mode: None, ..Default::default() },
            depth_stencil: None,
            multisample: Default::default(),
            multiview: None,
            cache: None,
        })
    }

    fn post_pipeline(device: &wgpu::Device, layout: &wgpu::BindGroupLayout, shader: &wgpu::ShaderModule, format: wgpu::TextureFormat) -> wgpu::RenderPipeline {
        let pll = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("post-pll"),
            bind_group_layouts: &[layout],
            push_constant_ranges: &[],
        });
        device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("post-pipeline"),
            layout: Some(&pll),
            vertex: wgpu::VertexState {
                module: shader,
                entry_point: "vs",
                buffers: &[],
                compilation_options: Default::default(),
            },
            fragment: Some(wgpu::FragmentState {
                module: shader,
                entry_point: "fs",
                targets: &[Some(wgpu::ColorTargetState {
                    format,
                    blend: None,
                    write_mask: wgpu::ColorWrites::ALL,
                })],
                compilation_options: Default::default(),
            }),
            primitive: wgpu::PrimitiveState { cull_mode: None, ..Default::default() },
            depth_stencil: None,
            multisample: Default::default(),
            multiview: None,
            cache: None,
        })
    }

    fn ui_pipeline(device: &wgpu::Device, l0: &wgpu::BindGroupLayout, l1: &wgpu::BindGroupLayout, shader: &wgpu::ShaderModule, format: wgpu::TextureFormat) -> wgpu::RenderPipeline {
        use ui::UiVertex;
        let pll = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("ui-pll"),
            bind_group_layouts: &[l0, l1],
            push_constant_ranges: &[],
        });
        device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("ui-pipeline"),
            layout: Some(&pll),
            vertex: wgpu::VertexState {
                module: shader,
                entry_point: "vs",
                buffers: &[UiVertex::LAYOUT],
                compilation_options: Default::default(),
            },
            fragment: Some(wgpu::FragmentState {
                module: shader,
                entry_point: "fs",
                targets: &[Some(wgpu::ColorTargetState {
                    format,
                    blend: Some(wgpu::BlendState::ALPHA_BLENDING),
                    write_mask: wgpu::ColorWrites::ALL,
                })],
                compilation_options: Default::default(),
            }),
            // Quads UI en TriangleList via index buffer partagé (voir ui_index_buf).
            primitive: wgpu::PrimitiveState {
                topology: wgpu::PrimitiveTopology::TriangleList,
                strip_index_format: None,
                front_face: wgpu::FrontFace::Ccw,
                cull_mode: None,
                unclipped_depth: false,
                polygon_mode: wgpu::PolygonMode::Fill,
                conservative: false,
            },
            depth_stencil: None,
            multisample: Default::default(),
            multiview: None,
            cache: None,
        })
    }

    fn make_offscreen(device: &wgpu::Device, w: u32, h: u32, format: wgpu::TextureFormat) -> (wgpu::Texture, wgpu::TextureView) {
        let tex = device.create_texture(&wgpu::TextureDescriptor {
            label: Some("offscreen"),
            size: wgpu::Extent3d { width: w, height: h, depth_or_array_layers: 1 },
            mip_level_count: 1,
            sample_count: 1,
            dimension: wgpu::TextureDimension::D2,
            format,
            usage: wgpu::TextureUsages::RENDER_ATTACHMENT | wgpu::TextureUsages::TEXTURE_BINDING,
            view_formats: &[],
        });
        let view = tex.create_view(&wgpu::TextureViewDescriptor::default());
        (tex, view)
    }

    fn make_depth(device: &wgpu::Device, w: u32, h: u32) -> (wgpu::Texture, wgpu::TextureView) {
        let tex = device.create_texture(&wgpu::TextureDescriptor {
            label: Some("depth"),
            size: wgpu::Extent3d { width: w, height: h, depth_or_array_layers: 1 },
            mip_level_count: 1,
            sample_count: 1,
            dimension: wgpu::TextureDimension::D2,
            format: wgpu::TextureFormat::Depth24Plus,
            usage: wgpu::TextureUsages::RENDER_ATTACHMENT | wgpu::TextureUsages::TEXTURE_BINDING,
            view_formats: &[],
        });
        let view = tex.create_view(&wgpu::TextureViewDescriptor::default());
        (tex, view)
    }

    /// Cible rgba16float de la passe RT (RENDER_ATTACHMENT + TEXTURE_BINDING).
    fn make_rt_target(device: &wgpu::Device, w: u32, h: u32, label: &str) -> (wgpu::Texture, wgpu::TextureView) {
        let tex = device.create_texture(&wgpu::TextureDescriptor {
            label: Some(label),
            size: wgpu::Extent3d { width: w, height: h, depth_or_array_layers: 1 },
            mip_level_count: 1,
            sample_count: 1,
            dimension: wgpu::TextureDimension::D2,
            format: wgpu::TextureFormat::Rgba16Float,
            usage: wgpu::TextureUsages::RENDER_ATTACHMENT
                | wgpu::TextureUsages::TEXTURE_BINDING
                | wgpu::TextureUsages::COPY_SRC, // debug dump rt0/rt1
            view_formats: &[],
        });
        let view = tex.create_view(&wgpu::TextureViewDescriptor::default());
        (tex, view)
    }

    pub fn size(&self) -> (u32, u32) {
        (self.surface_config.width, self.surface_config.height)
    }

    pub fn resize(&mut self, w: u32, h: u32) {
        let (w, h) = (w.max(1), h.max(1));
        self.surface_config.width = w;
        self.surface_config.height = h;
        self.surface.configure(&self.device, &self.surface_config);
        self.recreate_all_targets();
        let ui_data = [w as f32, h as f32, 0.0, 0.0];
        self.queue.write_buffer(&self.ui_uniform_buf, 0, bytemuck::cast_slice(&ui_data));
    }

    /// Recrée toutes les cibles dépendant de la taille interne (offscreen, depth,
    /// post, mv, historique) + rebranche les bind groups + invalide l'historique.
    fn recreate_all_targets(&mut self) {
        let (sw, sh) = self.scaled_size();
        let (t, v) = Self::make_offscreen(&self.device, sw, sh, self.surface_config.format);
        self.offscreen_tex = t;
        self.offscreen_view = v;
        self.rebuild_post_bind();
        let (dt, dv) = Self::make_depth(&self.device, sw, sh);
        self.depth_tex = dt;
        self.depth_view = dv;
        self.rebuild_rt_bind();
        self.recreate_rt_targets();
        // Les cibles RT viennent d'être remplacées : le bind group du MONDE
        // doit suivre, sinon il échantillonne les anciennes textures (vues
        // orphelines) → rt0/rt1 lus NOIRS en jeu (« le RT éteint tout »).
        self.rebuild_world_bind();
        self.recreate_ups_targets();
        self.reset_upscale = true;
    }

    /// Taille du buffer monde = surface × échelle de rendu × preset upscaling.
    fn scaled_size(&self) -> (u32, u32) {
        let k = self.render_scale * self.ups_scale;
        (
            ((self.surface_config.width as f32 * k) as u32).max(1),
            ((self.surface_config.height as f32 * k) as u32).max(1),
        )
    }

    fn rebuild_post_bind(&mut self) {
        let post_layout = self.post_pipeline.get_bind_group_layout(0);
        self.post_bind = self.device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("post-bind"),
            layout: &post_layout,
            entries: &[
                wgpu::BindGroupEntry { binding: 0, resource: self.post_uniform_buf.as_entire_binding() },
                wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::Sampler(&texture::linear_sampler(&self.device, false)) },
                wgpu::BindGroupEntry { binding: 2, resource: wgpu::BindingResource::TextureView(&self.offscreen_view) },
            ],
        });
    }

    /// Change l'échelle de rendu (recrée offscreen + depth, post/UI restent en pleine résolution).
    pub fn set_render_scale(&mut self, scale: f32) {
        let s = scale.clamp(0.45, 1.0);
        if (s - self.render_scale).abs() < 0.001 {
            return;
        }
        self.render_scale = s;
        self.recreate_all_targets();
    }

    // ---------- upscaling temporel (FSR 3 / DLSS) ----------

    /// Échelle interne des presets : qualité x1.5, équilibré x1.7, performance x2.0.
    fn ups_preset_scale(quality: u8) -> f32 {
        match quality.min(2) {
            0 => 1.0 / 1.5,
            1 => 1.0 / 1.7,
            _ => 0.5,
        }
    }

    /// Change d'upscaler et de preset qualité, recrée les cibles et invalide l'historique.
    pub fn set_upscaler(&mut self, mode: u8, quality: u8) {
        let mode = mode.min(2);
        let quality = quality.min(2);
        if mode == self.upscaler && quality == self.upscale_quality {
            return;
        }
        self.upscaler = mode;
        self.upscale_quality = quality;
        self.ups_scale = if mode == 0 { 1.0 } else { Self::ups_preset_scale(quality) };
        self.rcas_stops = match quality.min(2) {
            0 => 1.5,
            1 => 2.0,
            _ => 2.5,
        };
        self.recreate_all_targets();
    }

    pub fn ups_active(&self) -> bool {
        self.upscaler > 0
    }

    /// Taille interne de rendu (pour l'application du jitter NDC côté jeu).
    pub fn internal_size(&self) -> (u32, u32) {
        self.scaled_size()
    }

    /// Jitter Halton(2,3) 8 phases, en pixels internes (amplitude ±0.5 px).
    /// Retourne (jx, jy) ; met à jour la copie shader (jx, -jy).
    pub fn jitter_xy(&mut self) -> (f32, f32) {
        if self.upscaler == 0 {
            self.jitter_px = [0.0, 0.0];
            return (0.0, 0.0);
        }
        let phase = (self.frame_idx % 8) + 1;
        let jx = Self::halton(phase, 2) - 0.5;
        let jy = Self::halton(phase, 3) - 0.5;
        self.jitter_px = [jx, -jy];
        (jx, jy)
    }

    fn halton(mut i: u32, base: u32) -> f32 {
        let mut f = 1.0f32;
        let mut r = 0.0f32;
        while i > 0 {
            f /= base as f32;
            r += f * (i % base) as f32;
            i /= base;
        }
        r
    }

    /// (Re)crée les cibles de l'upscaling temporel et rebranche les bind groups.
    fn recreate_ups_targets(&mut self) {
        let (sw, sh) = self.scaled_size();
        let (w, h) = (self.surface_config.width, self.surface_config.height);
        let fmt = self.surface_config.format;
        let (t, v) = Self::make_ups_tex(&self.device, sw, sh, fmt, "ups-post");
        self.post_tex = t;
        self.post_view = v;
        let (t, v) = Self::make_ups_tex(&self.device, sw, sh, wgpu::TextureFormat::Rg16Float, "ups-mv");
        self.mv_tex = t;
        self.mv_view = v;
        let (t, v) = Self::make_ups_tex(&self.device, sw, sh, wgpu::TextureFormat::Rg16Float, "ups-mv-dil");
        self.mv_dil_tex = t;
        self.mv_dil_view = v;
        for i in 0..2 {
            let (t, v) = Self::make_ups_tex(&self.device, w, h, wgpu::TextureFormat::Rgba16Float, "ups-hist");
            self.hist_texs[i] = t;
            self.hist_views[i] = v;
        }
        self.hist_idx = 0;
        self.prev_vp = None;
        self.rebuild_ups_binds();
    }

    fn make_ups_tex(device: &wgpu::Device, w: u32, h: u32, fmt: wgpu::TextureFormat, label: &str) -> (wgpu::Texture, wgpu::TextureView) {
        let tex = device.create_texture(&wgpu::TextureDescriptor {
            label: Some(label),
            size: wgpu::Extent3d { width: w.max(1), height: h.max(1), depth_or_array_layers: 1 },
            mip_level_count: 1,
            sample_count: 1,
            dimension: wgpu::TextureDimension::D2,
            format: fmt,
            usage: wgpu::TextureUsages::RENDER_ATTACHMENT | wgpu::TextureUsages::TEXTURE_BINDING,
            view_formats: &[],
        });
        let view = tex.create_view(&wgpu::TextureViewDescriptor::default());
        (tex, view)
    }

    fn rebuild_ups_binds(&mut self) {
        let uni = self.ups_uniform_buf.as_entire_binding();
        self.mv_bind = self.device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("ups-mv-bind"),
            layout: &self.mv_bind_layout,
            entries: &[
                wgpu::BindGroupEntry { binding: 0, resource: uni.clone() },
                wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::TextureView(&self.depth_view) },
            ],
        });
        self.dilate_bind = self.device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("ups-dilate-bind"),
            layout: &self.dilate_bind_layout,
            entries: &[
                wgpu::BindGroupEntry { binding: 0, resource: uni.clone() },
                wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::TextureView(&self.depth_view) },
                wgpu::BindGroupEntry { binding: 4, resource: wgpu::BindingResource::TextureView(&self.mv_view) },
            ],
        });
        self.accum_bind = self.device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("ups-accum-bind"),
            layout: &self.accum_bind_layout,
            entries: &[
                wgpu::BindGroupEntry { binding: 0, resource: uni.clone() },
                wgpu::BindGroupEntry { binding: 2, resource: wgpu::BindingResource::Sampler(&texture::linear_sampler(&self.device, false)) },
                wgpu::BindGroupEntry { binding: 3, resource: wgpu::BindingResource::TextureView(&self.post_view) },
                wgpu::BindGroupEntry { binding: 5, resource: wgpu::BindingResource::TextureView(&self.mv_dil_view) },
                wgpu::BindGroupEntry { binding: 6, resource: wgpu::BindingResource::TextureView(&self.hist_views[self.hist_idx]) },
            ],
        });
        let out_idx = 1 - self.hist_idx;
        self.rcas_bind = self.device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("ups-rcas-bind"),
            layout: &self.rcas_bind_layout,
            entries: &[
                wgpu::BindGroupEntry { binding: 0, resource: uni },
                wgpu::BindGroupEntry { binding: 6, resource: wgpu::BindingResource::TextureView(&self.hist_views[out_idx]) },
            ],
        });
    }

    /// Pipeline fullscreen (triangle) générique pour les passes d'upscaling.
    fn ups_pipeline(device: &wgpu::Device, layout: &wgpu::BindGroupLayout, shader: &wgpu::ShaderModule, entry: &'static str, format: wgpu::TextureFormat) -> wgpu::RenderPipeline {
        let pll = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("ups-pll"),
            bind_group_layouts: &[layout],
            push_constant_ranges: &[],
        });
        device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("ups-pipeline"),
            layout: Some(&pll),
            vertex: wgpu::VertexState {
                module: shader,
                entry_point: "vs",
                buffers: &[],
                compilation_options: Default::default(),
            },
            fragment: Some(wgpu::FragmentState {
                module: shader,
                entry_point: entry,
                targets: &[Some(wgpu::ColorTargetState {
                    format,
                    blend: None,
                    write_mask: wgpu::ColorWrites::ALL,
                })],
                compilation_options: Default::default(),
            }),
            primitive: wgpu::PrimitiveState { cull_mode: None, ..Default::default() },
            depth_stencil: None,
            multisample: Default::default(),
            multiview: None,
            cache: None,
        })
    }

    // ---------- ray tracing (optionnel) ----------

    /// Échelle du tampon RT relativement à la SURFACE native. (Avant : 0.4/
    /// 0.5/0.6 du tampon monde, lui-même réduit par le DRS (×0.45) et l'FSR 3
    /// (×0.5) -> pire cas 0.09× l'écran = « RT ultra pixelisé ».)
    /// Qualité 0.7x · Ultra 0.8x · Overdrive 0.9x.
    fn rt_target_scale(mode: u8) -> f32 {
        match mode {
            2 => 0.8,
            3 => 0.9,
            _ => 0.7,
        }
    }

    /// Nombre approximatif de rayons lancés par pixel (miroir du budget du shader).
    /// Affiché dans le tag perf : c'est la preuve quantifiée que de VRAIS rayons
    /// sont lancés (et le coût se voit immédiatement sur lavapipe).
    pub fn rt_ray_count(mode: u8) -> u32 {
        match mode {
            // ombres néons ~2 + torche 1 + AO 1 + réflexion 2 + GI 1×(1 trace)
            1 => 7,
            // ombres 3 + AO 3 + réflexion 2 + GI 2×(2 traces + 1 ombre)
            2 => 14,
            // ombres 3 + AO 3 + réflexions 2×2 + GI 2×(3 traces + 3 ombres)
            3 => 26,
            _ => 0,
        }
    }

    /// Change de mode RT (0 désactivé / 1 qualité / 2 ultra / 3 overdrive path tracing).
    pub fn set_rt_mode(&mut self, mode: u8) {
        let mode = mode.min(3);
        if mode == self.rt_mode {
            return;
        }
        self.rt_mode = mode;
        self.rt_scale = Self::rt_target_scale(mode);
        self.recreate_rt_targets();
        self.rebuild_world_bind();
    }

    /// Recrée les cibles RT (dépendent du mode + de la taille de la surface).
    fn recreate_rt_targets(&mut self) {
        if self.rt_mode == 0 {
            return;
        }
        // Base = surface NATIVE : l'échelle interne (DRS) et l'upscaling FSR 3
        // réduisent déjà le tampon monde ; les multiplier par l'échelle RT
        // donnait un tampon RT minuscule (pire cas 0.09× l'écran = pixels
        // géants). Plafond DRS : si le GPU faiblit et que le DRS descend le
        // rendu monde, le RT suit (jamais sous 0.5× la surface) ; en rendu
        // natif l'échelle du mode s'applique telle quelle (0.7/0.8/0.9).
        let (uw, uh) = (self.surface_config.width.max(1), self.surface_config.height.max(1));
        let mut k = self.rt_scale;
        // Override QA (lavapipe logiciel) : SL3_RT_SCALE=0.4 par exemple.
        if let Ok(v) = std::env::var("SL3_RT_SCALE") {
            if let Ok(f) = v.parse::<f32>() {
                k = f.clamp(0.1, 1.0);
            }
        }
        let k = k.min((self.render_scale * self.ups_scale).max(0.5));
        let w = ((uw as f32 * k) as u32).clamp(1, uw);
        let h = ((uh as f32 * k) as u32).clamp(1, uh);
        let (t0, v0) = Self::make_rt_target(&self.device, w, h, "rt0");
        let (t1, v1) = Self::make_rt_target(&self.device, w, h, "rt1");
        self.rt0_tex = t0;
        self.rt1_tex = t1;
        self.rt0_view = v0;
        self.rt1_view = v1;
    }

    /// Rebranche les textures RT réelles ou neutres sur le bind group du monde.
    fn rebuild_world_bind(&mut self) {
        let (v0, v1) = if self.rt_mode > 0 {
            (&self.rt0_view, &self.rt1_view)
        } else {
            (&self.rt_neutral0, &self.rt_neutral1)
        };
        let bg = Self::make_world_bind0(&self.device, &self.world_bind_layout, &self.world_uniform_buf, v0, v1);
        self.world_bind0 = bg;
    }

    /// Rebranche la texture profondeur (change à chaque resize / changement d'échelle).
    fn rebuild_rt_bind(&mut self) {
        let bg = self.device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("rt-bind"),
            layout: &self.rt_bind_layout,
            entries: &[
                wgpu::BindGroupEntry { binding: 0, resource: self.rt_params_buf.as_entire_binding() },
                wgpu::BindGroupEntry { binding: 1, resource: self.world_uniform_buf.as_entire_binding() },
                wgpu::BindGroupEntry { binding: 2, resource: self.rt_static_buf.as_entire_binding() },
                wgpu::BindGroupEntry { binding: 3, resource: self.rt_dyn_buf.as_entire_binding() },
                wgpu::BindGroupEntry { binding: 4, resource: wgpu::BindingResource::TextureView(&self.depth_view) },
            ],
        });
        self.rt_bind = bg;
    }

    /// Reconstruit les boîtes statiques de la scène RT (au démarrage d'une partie).
    pub fn update_rt_statics(&mut self, map: &MapData, insts: &[(String, InstanceData)]) {
        let boxes = {
            let models = &self.models;
            rtscene::build_static_boxes(map, insts, |name| models.get(name).map(|m| m.bounds))
        };
        self.rt_static_count = boxes.len() as u32;
        println!("[rt] update_rt_statics : {} boîtes (statiques)", boxes.len());
        let mut padded = boxes;
        padded.resize(rtscene::MAX_RT_STATIC_BOXES, rtscene::GpuAabb::ZERO);
        self.queue.write_buffer(&self.rt_static_buf, 0, bytemuck::cast_slice(&padded));
    }

    pub fn render_scale(&self) -> f32 {
        self.render_scale
    }

    // ---------- construction des batchs statiques ----------
    pub fn build_static(&self, insts: &[(String, InstanceData)]) -> StaticBatches {
        let mut groups: HashMap<PartKey, Vec<InstanceRaw>> = HashMap::new();
        for (model_name, inst) in insts {
            if let Some(model) = self.models.get(model_name) {
                for (pi, part) in model.parts.iter().enumerate() {
                    groups
                        .entry(PartKey { model: model_name.clone(), part: pi })
                        .or_default()
                        .push(inst.raw());
                    let _ = &part.mat;
                }
            }
        }
        let mut batches = Vec::new();
        let mut total = 0usize;
        for (key, raws) in groups {
            let buffer = self.device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
                label: Some("static-instances"),
                contents: bytemuck::cast_slice(&raws),
                usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
            });
            total += raws.len();
            batches.push(StaticBatch { key, buffer, count: raws.len() as u32 });
        }
        StaticBatches { batches, total_instances: total }
    }

    // ---------- dessin ----------
    /// Construit les batches d'instances DYNAMIQUES avec le MÊME mécanisme que
    /// les statiques (`build_static` : `create_buffer_init` hors encoder) — le
    /// vertex-fetch d'instance des buffers réécrits dans le frame s'est révélé
    /// non fiable sur certains drivers (lavapipe : colonnes de matrice corrompues).
    /// Renvoie `None` s'il n'y a aucune instance (rien à dessiner).
    pub fn build_dyn(&self, dynamics: &[(String, Vec<InstanceData>)]) -> Option<DynBatches> {
        let mut groups: HashMap<PartKey, Vec<InstanceRaw>> = HashMap::new();
        for (model_name, insts) in dynamics {
            if insts.is_empty() {
                continue;
            }
            if model_name == "battery" && std::env::var("SL3_DEBUG").is_ok() {
                // Positions réellement envoyées au GPU (colonne translation).
                let trs: Vec<(f32, f32, f32)> =
                    insts.iter().map(|i| (i.model.w_axis.x, i.model.w_axis.y, i.model.w_axis.z)).collect();
                eprintln!("[sl3-debug] battery TRS: {trs:?}");
            }
            let Some(model) = self.models.get(model_name) else { continue };
            for (pi, _part) in model.parts.iter().enumerate() {
                let entry = groups
                    .entry(PartKey { model: model_name.clone(), part: pi })
                    .or_default();
                for inst in insts {
                    entry.push(inst.raw());
                }
            }
        }
        if groups.is_empty() {
            return None;
        }
        let mut plan = Vec::new();
        let mut offset = 0u64;
        let stride = std::mem::size_of::<InstanceRaw>() as u64;
        let mut max_end = 0u64;
        let mut batches: Vec<(PartKey, wgpu::Buffer, u32)> = Vec::new();
        let mut keys: Vec<PartKey> = groups.keys().cloned().collect();
        keys.sort_by(|a, b| a.model.cmp(&b.model).then(a.part.cmp(&b.part)));
        for key in keys {
            let raws = groups.get(&key).unwrap();
            let buf = self.device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
                label: Some("dyn-instances"),
                contents: bytemuck::cast_slice(raws),
                usage: wgpu::BufferUsages::VERTEX,
            });
            let count = raws.len() as u32;
            plan.push((key.clone(), offset, count));
            batches.push((key, buf, count));
            max_end = (offset + count as u64 * stride).max(max_end);
            offset += count as u64 * stride;
        }
        Some(DynBatches { plan, batches, max_end })
    }

    /// Dessine statiques + batches dynamiques (préparés hors encoder) avec le
    /// pipeline donné.
    fn draw_instances_pass(
        &self,
        pass: &mut wgpu::RenderPass<'static>,
        statics: &StaticBatches,
        dyns: Option<&DynBatches>,
        pipeline: &wgpu::RenderPipeline,
    ) {
        pass.set_pipeline(pipeline);
        pass.set_bind_group(0, &self.world_bind0, &[]);

        // Statiques.
        for batch in &statics.batches {
            self.draw_part(pass, &batch.key, &batch.buffer, batch.count);
        }

        // Dynamiques : même chemin que les statiques (buffer dédié par part,
        // créé hors encoder via create_buffer_init).
        if let Some(d) = dyns {
            let dbg = std::env::var("SL3_DEBUG").is_ok();
            for (key, buf, count) in &d.batches {
                if dbg {
                    let mat = self
                        .models
                        .get(&key.model)
                        .and_then(|m| m.parts.get(key.part))
                        .map(|p| p.mat.clone())
                        .unwrap_or_default();
                    let has_bg = self
                        .models
                        .get(&key.model)
                        .and_then(|m| m.parts.get(key.part))
                        .map(|p| self.material_bind_groups.contains_key(&p.mat))
                        .unwrap_or(false);
                    eprintln!(
                        "[sl3-debug] dyn draw: {} part={} n={} mat={:?} bg={}",
                        key.model, key.part, count, mat, has_bg
                    );
                }
                self.draw_part(pass, key, buf, *count);
            }
            let _ = &d.plan;
            let _ = d.max_end;
        }
    }

    fn draw_part(
        &self,
        pass: &mut wgpu::RenderPass<'static>,
        key: &PartKey,
        instance_buf: &wgpu::Buffer,
        count: u32,
    ) {
        let Some(model) = self.models.get(&key.model) else { return };
        let Some(part) = model.parts.get(key.part) else { return };
        let Some(bg) = self.material_bind_groups.get(&part.mat) else { return };
        pass.set_bind_group(1, bg, &[]);
        pass.set_vertex_buffer(0, part.vertex_buf.slice(..));
        pass.set_vertex_buffer(1, instance_buf.slice(..));
        pass.set_index_buffer(part.index_buf.slice(..), wgpu::IndexFormat::Uint32);
        pass.draw_indexed(0..part.count, 0, 0..count);
    }

    #[allow(clippy::too_many_arguments)]
    pub fn render(
        &mut self,
        world_uniform: &WorldUniform,
        rt: Option<RtFrame>,
        statics: &StaticBatches,
        dyns: Option<&DynBatches>,
        ui_ops: &[ui::UiOp],
        post_params: [f32; 4],
        ups: Option<UpsFrame>,
    ) -> Result<(), wgpu::SurfaceError> {
        let frame = self.surface.get_current_texture()?;
        let frame_view = frame.texture.create_view(&wgpu::TextureViewDescriptor::default());

        // Capture demandée ? On rend la frame dans une texture COPY_SRC dédiée
        // (mêmes pipelines : même format que la surface) au lieu de la swapchain.
        let capture_path = self.capture_path.take();
        let final_view;
        if capture_path.is_some() {
            let size = frame.texture.size();
            let rebuild = match &self.capture_tex {
                Some(t) => t.size() != size,
                None => true,
            };
            if rebuild {
                let tex = self.device.create_texture(&wgpu::TextureDescriptor {
                    label: Some("capture"),
                    size,
                    mip_level_count: 1,
                    sample_count: 1,
                    dimension: wgpu::TextureDimension::D2,
                    format: self.surface_config.format,
                    usage: wgpu::TextureUsages::RENDER_ATTACHMENT | wgpu::TextureUsages::COPY_SRC,
                    view_formats: &[],
                });
                self.capture_tex = Some(tex);
            }
            final_view = self
                .capture_tex
                .as_ref()
                .unwrap()
                .create_view(&wgpu::TextureViewDescriptor::default());
        } else {
            final_view = frame_view;
        }

        self.queue
            .write_buffer(&self.world_uniform_buf, 0, bytemuck::bytes_of(world_uniform));
        self.queue
            .write_buffer(&self.post_uniform_buf, 0, bytemuck::cast_slice(&post_params));

        // Ray tracing actif ? Prépare uniform + boîtes dynamiques.
        let rt_on = self.rt_mode > 0;
        if let (true, Some(f)) = (rt_on, &rt) {
            let (rt_w, rt_h) = (self.rt0_tex.size().width, self.rt0_tex.size().height);
            let (dw, dh) = (self.depth_tex.size().width, self.depth_tex.size().height);
            let params = RtParams {
                inv_vp: f.inv_vp,
                cam_pos: world_uniform.cam_pos,
                dims: [rt_w as f32, rt_h as f32, dw as f32, dh as f32],
                counts: [
                    self.rt_static_count as f32,
                    (f.dyn_boxes.len() as f32).min(rtscene::MAX_RT_DYN_BOXES as f32),
                    world_uniform.misc[0],
                    1.6,
                ],
                misc: [
                    match self.rt_mode {
                        2 => 0.85,
                        3 => 1.55, // NEE avec ombres portées : collecte moins que
                                   // la GI non-ombrée de Qualité -> on compense
                        _ => 0.4,
                    }, // force GI
                    0.35,
                    if self.rt_mode >= 2 { 3.0 } else { 1.0 }, // échantillons AO
                    0.0,
                ],
                // Path tracing : (échantillons GI, rebonds, budget ombres, échantillons réflexion)
                pt: match self.rt_mode {
                    2 => [2.0, 2.0, 1.0, 1.0],
                    3 => [2.0, 3.0, 2.0, 2.0],
                    _ => [1.0, 1.0, 0.0, 1.0],
                },
            };
            self.queue.write_buffer(&self.rt_params_buf, 0, bytemuck::bytes_of(&params));
            let mut boxes: Vec<rtscene::GpuAabb> = f
                .dyn_boxes
                .iter()
                .take(rtscene::MAX_RT_DYN_BOXES)
                .copied()
                .collect();
            boxes.resize(rtscene::MAX_RT_DYN_BOXES, rtscene::GpuAabb::ZERO);
            self.queue.write_buffer(&self.rt_dyn_buf, 0, bytemuck::cast_slice(&boxes));
        }

        // Quads UI.
        let (verts, draws) = ui::build_ui_verts(ui_ops, &self.font);

        // Debug : buffers de lecture rt0/rt1 copiés DANS le même encoder (ordre garanti).
        let mut staged_rt: Option<Vec<(wgpu::Buffer, u32, u32, u64)>> = None;
        if !verts.is_empty() {
            let bytes_needed = (verts.len() * std::mem::size_of::<ui::UiVertex>()) as u64;
            if self.ui_buf.size() < bytes_needed {
                self.ui_buf = self.device.create_buffer(&wgpu::BufferDescriptor {
                    label: Some("ui-verts"),
                    size: bytes_needed * 2,
                    usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
                    mapped_at_creation: false,
                });
            }
            // L'index buffer suit : 6 indices u32 par quad.
            let quads_needed = (verts.len() / 4) as u32;
            if self.ui_index_cap < quads_needed {
                let cap = (quads_needed * 2).max(8192);
                let mut idx: Vec<u32> = Vec::with_capacity(cap as usize * 6);
                for q in 0..cap {
                    let v = q * 4;
                    idx.extend_from_slice(&[v, v + 1, v + 2, v + 1, v + 3, v + 2]);
                }
                self.ui_index_buf = self.device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
                    label: Some("ui-indices"),
                    contents: bytemuck::cast_slice(&idx),
                    usage: wgpu::BufferUsages::INDEX,
                });
                self.ui_index_cap = cap;
            }
            self.queue.write_buffer(&self.ui_buf, 0, bytemuck::cast_slice(&verts));
        }

        // Upload des dynamiques (une seule fois, partagé par toutes les passes).


        let mut encoder = self.device.create_command_encoder(&wgpu::CommandEncoderDescriptor {
            label: Some("frame"),
        });

        // 1) Pré-pass profondeur + passe RT + monde (RT activé), ou monde seul.
        if rt_on {
            {
                let pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                    label: Some("prepass-depth"),
                    color_attachments: &[],
                    depth_stencil_attachment: Some(wgpu::RenderPassDepthStencilAttachment {
                        view: &self.depth_view,
                        depth_ops: Some(wgpu::Operations {
                            load: wgpu::LoadOp::Clear(1.0),
                            store: wgpu::StoreOp::Store,
                        }),
                        stencil_ops: None,
                    }),
                    timestamp_writes: None,
                    occlusion_query_set: None,
                });
                let mut pass = pass.forget_lifetime();
                self.draw_instances_pass(&mut pass, statics, dyns, &self.prepass_pipeline);
            }
            {
                let rt0_att = wgpu::RenderPassColorAttachment {
                    view: &self.rt0_view,
                    resolve_target: None,
                    ops: wgpu::Operations {
                        load: wgpu::LoadOp::Clear(wgpu::Color::BLACK),
                        store: wgpu::StoreOp::Store,
                    },
                };
                let rt1_att = wgpu::RenderPassColorAttachment {
                    view: &self.rt1_view,
                    resolve_target: None,
                    ops: wgpu::Operations {
                        load: wgpu::LoadOp::Clear(wgpu::Color::BLACK),
                        store: wgpu::StoreOp::Store,
                    },
                };
                let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                    label: Some("rt-pass"),
                    color_attachments: &[Some(rt0_att), Some(rt1_att)],
                    depth_stencil_attachment: None,
                    timestamp_writes: None,
                    occlusion_query_set: None,
                });
                pass.set_pipeline(&self.rt_pipeline);
                pass.set_bind_group(0, &self.rt_bind, &[]);
                pass.draw(0..3, 0..1);
                static RT_FRAMES: std::sync::atomic::AtomicU32 = std::sync::atomic::AtomicU32::new(0);
                let n = RT_FRAMES.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
                if n < 3 || n % 25 == 0 {
                    eprintln!(
                        "[rt] passe {} : tampon {}x{}, statiques {}, dynamiques {}",
                        n,
                        self.rt0_tex.size().width,
                        self.rt0_tex.size().height,
                        self.rt_static_count,
                        self.rt_dyn_buf.size() / std::mem::size_of::<rtscene::GpuAabb>() as u64
                    );
                }
                drop(pass); // fin de la passe : l'encodeur redevient utilisable
            }
            // Copie de lecture (debug dump) : APRÈS la fin de la passe (une
            // copie pendant une passe active invalide l'encodeur sous wgpu 22).
            // Déclenchée sur la frame de capture EN JEU (données de CETTE frame).
            if std::env::var("SL3_RT_DUMP").is_ok()
                && self.rt_static_count > 0
                && capture_path.is_some()
            {
                static DUMPED: std::sync::atomic::AtomicBool = std::sync::atomic::AtomicBool::new(false);
                if !DUMPED.swap(true, std::sync::atomic::Ordering::Relaxed) {
                    let mut staged = Vec::new();
                    for tex in [&self.rt0_tex, &self.rt1_tex] {
                        let size = tex.size();
                        let (w, h) = (size.width, size.height);
                        let bpr = (w * 8).div_ceil(256) * 256;
                        let buf = self.device.create_buffer(&wgpu::BufferDescriptor {
                            label: Some("rt-read"),
                            size: (bpr * h) as u64,
                            usage: wgpu::BufferUsages::COPY_DST | wgpu::BufferUsages::MAP_READ,
                            mapped_at_creation: false,
                        });
                        encoder.copy_texture_to_buffer(
                            wgpu::ImageCopyTexture {
                                texture: tex,
                                mip_level: 0,
                                origin: wgpu::Origin3d::ZERO,
                                aspect: wgpu::TextureAspect::All,
                            },
                            wgpu::ImageCopyBuffer {
                                buffer: &buf,
                                layout: wgpu::ImageDataLayout {
                                    offset: 0,
                                    bytes_per_row: Some(bpr),
                                    rows_per_image: Some(h),
                                },
                            },
                            size,
                        );
                        staged.push((buf, w, h, bpr as u64));
                    }
                    staged_rt = Some(staged);
                }
            }
            {
                let pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                    label: Some("world-pass-rt"),
                    color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                        view: &self.offscreen_view,
                        resolve_target: None,
                        ops: wgpu::Operations {
                            load: wgpu::LoadOp::Clear(wgpu::Color {
                                r: 0.004,
                                g: 0.005,
                                b: 0.008,
                                a: 1.0,
                            }),
                            store: wgpu::StoreOp::Store,
                        },
                    })],
                    depth_stencil_attachment: Some(wgpu::RenderPassDepthStencilAttachment {
                        view: &self.depth_view,
                        depth_ops: Some(wgpu::Operations {
                            load: wgpu::LoadOp::Load,
                            store: wgpu::StoreOp::Store,
                        }),
                        stencil_ops: None,
                    }),
                    timestamp_writes: None,
                    occlusion_query_set: None,
                });
                let mut pass = pass.forget_lifetime();
                self.draw_instances_pass(&mut pass, statics, dyns, &self.world_pipeline_rt);
            }
        } else {
            let pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                label: Some("world-pass"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                    view: &self.offscreen_view,
                    resolve_target: None,
                    ops: wgpu::Operations {
                        load: wgpu::LoadOp::Clear(wgpu::Color {
                            r: 0.004,
                            g: 0.005,
                            b: 0.008,
                            a: 1.0,
                        }),
                        store: wgpu::StoreOp::Store,
                    },
                })],
                depth_stencil_attachment: Some(wgpu::RenderPassDepthStencilAttachment {
                    view: &self.depth_view,
                    depth_ops: Some(wgpu::Operations {
                        load: wgpu::LoadOp::Clear(1.0),
                        store: wgpu::StoreOp::Store,
                    }),
                    stencil_ops: None,
                }),
                timestamp_writes: None,
                occlusion_query_set: None,
            });
            // 'pass borrow self...' : étendre la durée de vie via transmute sûr ici
            let mut pass = pass.forget_lifetime();
            self.draw_instances_pass(&mut pass, statics, dyns, &self.world_pipeline);
        }

        // 2) Post-process -> cible pleine résolution (natif) ou basse résolution
        //    (upscaling temporel : l'accumulation fera le passage à pleine résolution).
        let ups_active = self.upscaler > 0 && ups.is_some();
        let reset_ups = self.reset_upscale;
        self.reset_upscale = false;
        if ups_active {
            // Uniform des passes d'upscaling (matrices + jitter + tailles).
            let f = ups.as_ref().unwrap();
            let (sw, sh) = self.scaled_size();
            let (w, h) = (self.surface_config.width, self.surface_config.height);
            let params = UpsParams {
                display_size: [w as f32, h as f32, 1.0 / w as f32, 1.0 / h as f32],
                render_size: [sw as f32, sh as f32, 1.0 / sw as f32, 1.0 / sh as f32],
                jitter: [
                    self.jitter_px[0],
                    self.jitter_px[1],
                    if reset_ups { 1.0 } else { 0.0 },
                    self.rcas_stops,
                ],
                inv_vp_cur: f.inv_vp,
                vp_prev: self.prev_vp.unwrap_or(world_uniform.view_proj),
            };
            self.queue.write_buffer(&self.ups_uniform_buf, 0, bytemuck::bytes_of(&params));
        }
        {
            let target_view = if ups_active { &self.post_view } else { &final_view };
            let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                label: Some("post-pass"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                    view: target_view,
                    resolve_target: None,
                    ops: wgpu::Operations {
                        load: wgpu::LoadOp::Clear(wgpu::Color::BLACK),
                        store: wgpu::StoreOp::Store,
                    },
                })],
                depth_stencil_attachment: None,
                timestamp_writes: None,
                occlusion_query_set: None,
            });
            pass.set_pipeline(&self.post_pipeline);
            pass.set_bind_group(0, &self.post_bind, &[]);
            pass.draw(0..3, 0..1);
        }

        // 2b) FSR 3 / DLSS : vecteurs de mouvement -> dilatation -> accumulation
        //     temporelle (Lanczos + box de rectification) -> RCAS.
        if ups_active {
            {
                let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                    label: Some("ups-mv"),
                    color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                        view: &self.mv_view,
                        resolve_target: None,
                        ops: wgpu::Operations {
                            load: wgpu::LoadOp::Clear(wgpu::Color::BLACK),
                            store: wgpu::StoreOp::Store,
                        },
                    })],
                    depth_stencil_attachment: None,
                    timestamp_writes: None,
                    occlusion_query_set: None,
                });
                pass.set_pipeline(&self.mv_pipeline);
                pass.set_bind_group(0, &self.mv_bind, &[]);
                pass.draw(0..3, 0..1);
            }
            {
                let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                    label: Some("ups-dilate"),
                    color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                        view: &self.mv_dil_view,
                        resolve_target: None,
                        ops: wgpu::Operations {
                            load: wgpu::LoadOp::Clear(wgpu::Color::BLACK),
                            store: wgpu::StoreOp::Store,
                        },
                    })],
                    depth_stencil_attachment: None,
                    timestamp_writes: None,
                    occlusion_query_set: None,
                });
                pass.set_pipeline(&self.dilate_pipeline);
                pass.set_bind_group(0, &self.dilate_bind, &[]);
                pass.draw(0..3, 0..1);
            }
            {
                let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                    label: Some("ups-accum"),
                    color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                        view: &self.hist_views[1 - self.hist_idx],
                        resolve_target: None,
                        ops: wgpu::Operations {
                            load: wgpu::LoadOp::Clear(wgpu::Color::BLACK),
                            store: wgpu::StoreOp::Store,
                        },
                    })],
                    depth_stencil_attachment: None,
                    timestamp_writes: None,
                    occlusion_query_set: None,
                });
                pass.set_pipeline(&self.accum_pipeline);
                pass.set_bind_group(0, &self.accum_bind, &[]);
                pass.draw(0..3, 0..1);
            }
            self.hist_idx = 1 - self.hist_idx;
            self.rebuild_ups_binds();
            {
                let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                    label: Some("ups-rcas"),
                    color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                        view: &final_view,
                        resolve_target: None,
                        ops: wgpu::Operations {
                            load: wgpu::LoadOp::Clear(wgpu::Color::BLACK),
                            store: wgpu::StoreOp::Store,
                        },
                    })],
                    depth_stencil_attachment: None,
                    timestamp_writes: None,
                    occlusion_query_set: None,
                });
                pass.set_pipeline(&self.rcas_pipeline);
                pass.set_bind_group(0, &self.rcas_bind, &[]);
                pass.draw(0..3, 0..1);
            }
            self.frame_idx = self.frame_idx.wrapping_add(1);
            self.prev_vp = Some(world_uniform.view_proj);
        }

        // 3) UI -> surface.
        if !verts.is_empty() {
            let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                label: Some("ui-pass"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                    view: &final_view,
                    resolve_target: None,
                    ops: wgpu::Operations {
                        load: wgpu::LoadOp::Load,
                        store: wgpu::StoreOp::Store,
                    },
                })],
                depth_stencil_attachment: None,
                timestamp_writes: None,
                occlusion_query_set: None,
            });
            pass.set_pipeline(&self.ui_pipeline);
            pass.set_bind_group(0, &self.ui_bind0, &[]);
            pass.set_index_buffer(self.ui_index_buf.slice(..), wgpu::IndexFormat::Uint32);
            let stride = std::mem::size_of::<ui::UiVertex>() as u64;
            // Un seul vertex buffer global : les indices du motif pointent en absolu.
            let total_bytes = verts.len() as u64 * stride;
            pass.set_vertex_buffer(0, self.ui_buf.slice(0..total_bytes));
            let mut cursor = 0u64;
            for (_op, (is_text, quads)) in ui_ops.iter().zip(draws.iter()) {
                if *quads == 0 {
                    continue;
                }
                match is_text {
                    true => pass.set_bind_group(1, &self.font_bg, &[]),
                    false => pass.set_bind_group(1, &self.white_bg, &[]),
                }
                // Chaque quad de 4 sommets consomme 6 indices du motif partagé.
                let q0 = (cursor / stride / 4) as u32;
                pass.draw_indexed(q0 * 6..(q0 + *quads) * 6, 0, 0..1);
                cursor += *quads as u64 * 4 * stride;
            }
        }

        self.queue.submit(Some(encoder.finish()));
        frame.present();
        if let Some(path) = capture_path {
            self.save_capture(&path);
            // Debug QA : SL3_RT_DUMP=1 exporte aussi rt0 (ao/ombres) et rt1 (gi/réflexions).
            if self.rt_mode > 0 && std::env::var("SL3_RT_DUMP").is_ok() {
                if let Some(staged) = staged_rt {
                    self.dump_rt(&path, &staged);
                }
            }
        }
        Ok(())
    }

    /// f16 (rgba16float) -> f32, décodeur minimal pour l'export debug.
    fn f16_to_f32(h: u16) -> f32 {
        // signe : bit 15 → -1.0 / 1.0 (un signe 0/1 multipliait tout positif
        // par 0.0 : le dump affichait « tout à zéro » alors que la passe écrivait).
        let sign = if (h >> 15) & 1 == 1 { -1.0 } else { 1.0 };
        let exp = ((h >> 10) & 0x1f) as i32;
        let frac = (h & 0x3ff) as f32;
        if exp == 0 {
            return sign * frac * 2f32.powi(-24); // sous-normaux
        }
        if exp == 31 {
            return f32::INFINITY;
        }
        sign * (1.0 + frac / 1024.0) * 2f32.powi(exp - 15)
    }

    /// Exporte rt0/rt1 en PNG (lecture bloquante) : diagnostique la passe RT
    /// sans deviner — ao/ombres/torche d'un côté, gi/réflexions de l'autre.
    fn dump_rt(&self, path: &std::path::Path, staged: &[(wgpu::Buffer, u32, u32, u64)]) {
        for (name, s) in [("rt0", &staged[0]), ("rt1", &staged[1])] {
            let (buf, w, h, bpr) = (&s.0, s.1, s.2, s.3);
            let (tx, rx) = std::sync::mpsc::channel();
            buf.slice(..).map_async(wgpu::MapMode::Read, move |r| {
                let _ = tx.send(r);
            });
            let _ = self.device.poll(wgpu::Maintain::Wait);
            if rx.recv().is_err() {
                continue;
            }
            let data = buf.slice(..).get_mapped_range();
            let mut mn = f32::MAX;
            let mut mx = f32::MIN;
            let mut px: Vec<u8> = Vec::with_capacity((w * h * 3) as usize);
            for row in 0..h {
                let base = (row as u64 * bpr) as usize;
                for col in 0..w {
                    let o = base + (col * 8) as usize;
                    for c in 0..3usize {
                        let bits = u16::from_le_bytes([data[o + c * 2], data[o + c * 2 + 1]]);
                        let v = Self::f16_to_f32(bits);
                        mn = mn.min(v);
                        mx = mx.max(v);
                        let v = v.clamp(0.0, 1.0);
                        // boost ×4 pour la lisibilité (les valeurs RT sont sombres)
                        px.push((v.min(0.25) * 1020.0) as u8);
                    }
                }
            }
            drop(data);
            buf.unmap();
            println!("[rt-dump] {name} : min={mn:.4} max={mx:.4}");
            let mut img = image::RgbImage::new(w, h);
            for (i, p) in px.chunks(3).enumerate() {
                img.put_pixel((i as u32) % w, (i as u32) / w, image::Rgb([p[0], p[1], p[2]]));
            }
            let stem = path.file_stem().map(|s| s.to_string_lossy().to_string()).unwrap_or_default();
            let dir = path.parent().map(|d| d.to_path_buf()).unwrap_or_default();
            let out = dir.join(format!("{stem}_{name}.png"));
            let _ = img.save(&out);
            println!("[rt-dump] {out:?}");
        }
    }

    /// Écrit la texture de capture dans un PNG (lecture bloquante one-shot).
    fn save_capture(&self, path: &std::path::Path) {
        let Some(tex) = &self.capture_tex else { return };
        let size = tex.size();
        let (w, h) = (size.width, size.height);
        let bpr = (w * 4).div_ceil(256) * 256;
        let buf = self.device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("capture-read"),
            size: (bpr * h) as u64,
            usage: wgpu::BufferUsages::COPY_DST | wgpu::BufferUsages::MAP_READ,
            mapped_at_creation: false,
        });
        let mut enc = self.device.create_command_encoder(&wgpu::CommandEncoderDescriptor {
            label: Some("capture-copy"),
        });
        enc.copy_texture_to_buffer(
            wgpu::ImageCopyTexture {
                texture: tex,
                mip_level: 0,
                origin: wgpu::Origin3d::ZERO,
                aspect: wgpu::TextureAspect::All,
            },
            wgpu::ImageCopyBuffer {
                buffer: &buf,
                layout: wgpu::ImageDataLayout {
                    offset: 0,
                    bytes_per_row: Some(bpr),
                    rows_per_image: Some(h),
                },
            },
            size,
        );
        self.queue.submit(Some(enc.finish()));
        buf.slice(..).map_async(wgpu::MapMode::Read, |_| {});
        let _ = self.device.poll(wgpu::Maintain::Wait);
        {
            let data = buf.slice(..).get_mapped_range();
            let mut rgba = Vec::with_capacity((w * h * 4) as usize);
            for row in 0..h {
                let start = (row * bpr) as usize;
                rgba.extend_from_slice(&data[start..start + (w * 4) as usize]);
            }
            if let Err(e) = image::save_buffer_with_format(path, &rgba, w, h, image::ColorType::Rgba8, image::ImageFormat::Png) {
                eprintln!("[capture] échec {} : {e}", path.display());
            } else {
                println!("[capture] {} ({}x{})", path.display(), w, h);
            }
        }
        buf.unmap();
    }
}
